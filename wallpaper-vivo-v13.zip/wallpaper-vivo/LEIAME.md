# Wallpaper Vivo

1. Instale o Node.js (nodejs.org).
2. Nesta pasta: `npm install` e depois `npm start`.
3. Para gerar o instalador .exe: `npm run dist` (saída em `dist/`).

Windows 10/11: o wallpaper é encaixado atrás dos ícones pelo pacote `electron-as-wallpaper`.
Se ele não instalar, o app abre o wallpaper numa janela comum no fundo.
Aceita vídeo (mp4/webm), imagem/GIF e páginas HTML, além de 5 animações incluídas.

## Loja

Aba **Loja** do painel: busca e baixa wallpapers direto das fontes abaixo. Os arquivos ficam na sua pasta de dados do app e entram na Biblioteca.

- **Wallhaven** (imagens): sem chave, só conteúdo seguro (SFW).
- **Pexels** e **Pixabay** (vídeos): precisam de uma chave gratuita. Clique em *Fontes* na Loja.
- **Link direto**: cole o endereço de um mp4, webm, jpg, png, webp ou gif.
- **Catálogos da comunidade**: qualquer pessoa pode publicar um arquivo JSON (por exemplo, no GitHub) e você adiciona o link em *Fontes*.

Formato do catálogo:

```json
{
  "name": "Meu catálogo",
  "items": [
    { "title": "Aurora", "type": "video", "url": "https://exemplo.com/aurora.mp4",
      "thumb": "https://exemplo.com/aurora.jpg", "author": "Fulano", "license": "CC0", "page": "https://exemplo.com/aurora" }
  ]
}
```

Os arquivos pertencem aos seus autores e cada fonte tem a sua licença. Confira antes de redistribuir.

## Pasta observada e arrastar-e-soltar

- **Pasta observada** (painel, lado direito): ative e escolha uma pasta dedicada (o padrão é *Imagens\Wallpaper Vivo*). Qualquer imagem ou vídeo salvo nela entra sozinho na Biblioteca. Se você apagar o arquivo da pasta, ele some da Biblioteca. Ao remover um item pelo app, o arquivo da pasta **não** é apagado e o app não o adiciona de novo.
- **Arrastar e soltar**: arraste arquivos do Explorador, ou uma imagem direto de uma página do navegador, para a janela do app.

## Atualização remota (como publicar versões novas)

O app consegue se atualizar sozinho a partir do **GitHub Releases** (grátis). Uma vez só:

1. Crie um repositório no GitHub (pode ser público), por exemplo `wallpaper-vivo`.
2. No `package.json`, em `build.publish`, troque `SEU-USUARIO` pelo seu usuário (e `repo`, se mudou o nome).
3. Crie um token em GitHub → Settings → Developer settings → Personal access tokens (permissão `repo`) e, no terminal: `set GH_TOKEN=seu_token` (Windows).
4. Aumente o `version` no `package.json` (ex.: 1.0.0 → 1.1.0) e rode `npm run release`. Isso gera o instalador e publica a versão no GitHub.

Quem já tem o app instalado (a partir da versão com este recurso) recebe a atualização: o app baixa sozinho e pede para reiniciar. Quem tem uma versão **antiga, sem este recurso**, precisa instalar uma vez a versão nova manualmente.

Para rodar `npm start` depois desta versão, rode `npm install` uma vez (nova dependência: electron-updater).

## Estúdio (Criar wallpaper) e blocos do modo código

- **Criar wallpaper** abre o Estúdio: você monta o wallpaper em **camadas**, como em um editor de imagem. Clique nos botões da lista para adicionar: imagem/GIF/vídeo seu, chuva, neve, estrelas, partículas, ondas, aurora, espectro de som, texto, relógio, formas, brilho no cursor e filtros de tela. Cada camada tem ajustes simples (cor, tamanho, posição, quanto reage ao cursor e à música). Dá para esconder, duplicar, apagar e reordenar camadas, e há **modelos prontos** para começar.
- **Criar com código** agora tem uma paleta de **blocos prontos**: clique no bloco e ele é inserido no lugar certo do código, com comentários explicando o que cada linha faz. Quem quiser pode editar o código à mão depois.

## Monitores e início com o Windows

- **Monitores**: em *Desempenho*, marque em quais monitores o wallpaper aparece (qualquer combinação, não só o principal). O botão *Identificar monitores* mostra o número de cada um na tela por 2 segundos.
- **Iniciar com o Windows**: o app grava a própria entrada de inicialização e abre direto na bandeja, sem janela. Rodando com `npm start`, a entrada aponta para o `electron.exe` + a pasta do projeto; com o programa **instalado** (`npm run dist`), aponta para o `Wallpaper Vivo.exe`. Se sobrar uma entrada antiga chamada "Electron", o app remove ao ligar/desligar a opção; se ainda aparecer, desative em *Gerenciador de Tarefas → Inicializar*.

## Pausa com jogos e tela cheia

O app olha todas as janelas grandes abertas (não só a que está em foco). Se alguma cobrir um monitor inteiro (jogo, vídeo em tela cheia, apresentação), o wallpaper pausa. Em *Desempenho → Pausar em* você escolhe: **Todos os monitores** (padrão, libera mais a placa de vídeo durante o jogo) ou **Só o monitor coberto**. Janelas apenas maximizadas, que deixam a barra de tarefas à mostra, não pausam.
