// Fontes da loja: APIs oficiais (Wallhaven, Pexels, Pixabay) + catálogos JSON + download seguro.
const fs = require('fs'), path = require('path');
const UA = 'WallpaperVivo/1.0';
const ALLOWED = ['.mp4', '.webm', '.jpg', '.jpeg', '.png', '.webp', '.gif'];
const CT = { 'video/mp4': '.mp4', 'video/webm': '.webm', 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' };
const MAX = 1024 * 1024 * 1024; // 1 GB por arquivo
const cache = new Map();

async function getJSON(url, headers = {}, ttl = 10 * 60 * 1000) {
  const k = url + '|' + (headers.Authorization || '');
  const hit = cache.get(k);
  if (ttl && hit && Date.now() - hit.t < ttl) return hit.j;
  const r = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json', ...headers } });
  if (r.status === 401 || r.status === 403) throw new Error('Chave inválida ou sem permissão.');
  if (r.status === 400) throw new Error('Pedido recusado pela fonte (confira a chave e a busca).');
  if (r.status === 429) throw new Error('Muitas buscas em pouco tempo. Espere um minuto e tente de novo.');
  if (!r.ok) throw new Error('A fonte respondeu com erro ' + r.status + '.');
  const j = await r.json();
  if (ttl) cache.set(k, { t: Date.now(), j });
  return j;
}
const qs = o => new URLSearchParams(o).toString();

async function wallhaven({ q, page, cats }) {
  const p = { q: q || '', categories: cats || '110', purity: '100', sorting: q ? 'relevance' : 'toplist', atleast: '1920x1080', ratios: '16x9,16x10', page: page || 1 };
  if (!q) p.topRange = '1M';
  const j = await getJSON('https://wallhaven.cc/api/v1/search?' + qs(p));
  return { items: (j.data || []).map(d => ({ id: d.id, key: 'wallhaven:' + d.id, title: 'Wallhaven ' + d.id, author: '', thumb: (d.thumbs || {}).large || '',
    type: 'image', url: d.path, page: d.url, source: 'Wallhaven', info: d.resolution })), hasMore: !!j.meta && j.meta.current_page < j.meta.last_page };
}

function pickFile(files) {
  const mp4 = (files || []).filter(f => f.file_type === 'video/mp4' && f.width).sort((a, b) => a.width - b.width);
  return mp4.find(f => f.width >= 1920) || mp4[mp4.length - 1];
}
async function pexels({ q, page }, key) {
  if (!key) throw new Error('KEY');
  const u = q ? 'https://api.pexels.com/videos/search?' + qs({ query: q, orientation: 'landscape', size: 'large', per_page: 24, page: page || 1 })
              : 'https://api.pexels.com/videos/popular?' + qs({ min_width: 1920, per_page: 24, page: page || 1 });
  const j = await getJSON(u, { Authorization: key });
  const items = (j.videos || []).map(v => { const f = pickFile(v.video_files); if (!f) return null;
    return { id: v.id, key: 'pexels:' + v.id, title: 'Pexels ' + v.id, author: (v.user || {}).name || '', thumb: v.image || '', type: 'video', url: f.link, page: v.url,
      source: 'Pexels', info: f.width + '×' + f.height + ' · ' + v.duration + 's' }; }).filter(Boolean);
  return { items, hasMore: !!j.next_page };
}

async function pixabay({ q, page, type }, key) {
  if (!key) throw new Error('KEY');
  const pg = page || 1;
  const j = await getJSON('https://pixabay.com/api/videos/?' + qs({ key, q: q || '', per_page: 24, page: pg, safesearch: 'true', video_type: type || 'all' }), {}, 24 * 3600 * 1000); // regra da API: cache de 24 h
  const items = (j.hits || []).map(h => { const V = h.videos || {}, v = V.large && V.large.url ? V.large : V.medium;
    if (!v || !v.url) return null;
    return { id: h.id, key: 'pixabay:' + h.id, title: ((h.tags || '').split(',')[0] || 'Pixabay ' + h.id).trim(), author: h.user || '', thumb: v.thumbnail || '',
      type: 'video', url: v.url, page: h.pageURL, source: 'Pixabay', info: v.width + '×' + v.height + ' · ' + h.duration + 's' }; }).filter(Boolean);
  return { items, hasMore: pg * 24 < (j.totalHits || 0) };
}

// nekos.best: animes SFW, sem chave. Categorias vêm de /endpoints (umas são imagens PNG, outras GIFs animados).
async function nekos({ q }) {
  const eps = await getJSON('https://nekos.best/api/v2/endpoints', {}, 24 * 3600 * 1000), cats = Object.keys(eps);
  const want = String(q || '').toLowerCase().trim(), cat = cats.includes(want) ? want : (cats.includes('neko') ? 'neko' : cats[0]);
  const j = await getJSON('https://nekos.best/api/v2/' + encodeURIComponent(cat) + '?amount=20', {}, 0);
  const fmt = ((eps[cat] || {}).format || 'png').toUpperCase();
  const items = (j.results || []).filter(r => r && /^https?:\/\//i.test(r.url || '')).map(r => { const id = r.url.split('/').pop().replace(/\.\w+$/, '');
    return { id, key: 'nekos:' + id, title: r.anime_name || cat, author: r.artist_name || '', thumb: r.url, type: 'image', url: r.url,
      page: /^https:\/\//i.test(r.source_url || '') ? r.source_url : '', source: 'nekos.best', info: fmt }; });
  return { items, hasMore: true, chips: cats.map(c => [c, (eps[c] || {}).format || 'png']) };
}
const typeOf = f => ['.mp4', '.webm'].includes(path.extname(f).toLowerCase()) ? 'video' : 'image';
async function catalog(url, q) {
  const j = await getJSON(url, {}, 60 * 1000), t = (q || '').toLowerCase();
  const items = (Array.isArray(j.items) ? j.items : []).filter(i => i && /^https?:\/\//i.test(i.url || '') && (!t || String(i.title || '').toLowerCase().includes(t)))
    .map((i, n) => ({ id: i.id || n, key: 'cat:' + url + ':' + (i.id || i.url), title: String(i.title || 'Sem título'), author: String(i.author || ''), thumb: String(i.thumb || ''),
      type: i.type === 'image' || i.type === 'video' ? i.type : typeOf(i.url.split('?')[0]), url: i.url, page: String(i.page || ''), source: String(j.name || 'Catálogo'), info: String(i.license || '') }));
  return { items, hasMore: false };
}

async function download(url, dir, base, onProgress) {
  if (!/^https?:\/\//i.test(url)) throw new Error('Link inválido.');
  const res = await fetch(url, { headers: { 'User-Agent': UA }, redirect: 'follow' });
  if (!res.ok) throw new Error('Não foi possível baixar (erro ' + res.status + ').');
  const ct = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (/^text\/|html|json/.test(ct)) throw new Error('O link não aponta para um vídeo ou imagem.');
  let ext = CT[ct];
  if (!ext) { try { ext = path.extname(new URL(res.url || url).pathname).toLowerCase(); } catch { ext = ''; } }
  if (!ALLOWED.includes(ext)) throw new Error('Tipo de arquivo não suportado (use mp4, webm, jpg, png, webp ou gif).');
  const total = +res.headers.get('content-length') || 0;
  if (total > MAX) throw new Error('Arquivo grande demais (máximo 1 GB).');
  const file = path.join(dir, base.replace(/[^a-z0-9._-]/gi, '_').slice(0, 80) + ext), tmp = file + '.part';
  const out = fs.createWriteStream(tmp); let got = 0, last = 0;
  try {
    const reader = res.body.getReader();
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      got += value.length; if (got > MAX) throw new Error('Arquivo grande demais (máximo 1 GB).');
      if (!out.write(value)) await new Promise(r => out.once('drain', r));
      const now = Date.now(); if (onProgress && now - last > 120) { last = now; onProgress(total ? got / total : -1); }
    }
    await new Promise((ok, bad) => { out.on('error', bad); out.end(ok); });
    fs.renameSync(tmp, file);
  } catch (e) { out.destroy(); try { fs.unlinkSync(tmp); } catch {} throw e; }
  if (onProgress) onProgress(1);
  return file;
}
module.exports = { wallhaven, nekos, pexels, pixabay, catalog, download, typeOf, json: u => getJSON(u, {}, 0) };
