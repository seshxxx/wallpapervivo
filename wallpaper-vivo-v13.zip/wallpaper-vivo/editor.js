// ===== Interface do Estúdio (criar wallpaper) e da paleta de blocos do modo código =====
(() => {
const ST = window.STUDIO, g = id => document.getElementById(id), el = (tag, props = {}, ...kids) => { const e = Object.assign(document.createElement(tag), props); kids.forEach(k => e.append(k)); return e; };
Object.assign(ICON, {
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 6.1A9.8 9.8 0 0 1 12 5c6 0 10 7 10 7a17 17 0 0 1-3.2 3.9M6.5 6.9C3.8 8.7 2 12 2 12s4 7 10 7c1.5 0 2.9-.4 4.1-1"/>',
  up: '<path d="M6 15l6-6 6 6"/>', down: '<path d="M6 9l6 6 6-6"/>', copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>' });

// ---------------- Estúdio ----------------
let stp = null, stRun = null, sel = 0, timer = null, built = false;
const layers = () => stp.cfg.layers, curObj = () => sel === 0 ? stp.cfg.bg : layers()[sel - 1], curType = () => sel === 0 ? 'bg' : curObj().type;
function restart() { clearTimeout(timer); timer = setTimeout(() => { stRun && stRun.stop(); stRun = runStudio(stp.cfg, g('stc'), 30); stRun.resize(640, 360); }, 60); }

function propRow(p, obj) {
  const row = el('div', { className: 'prow' }, el('div', { className: 'pl', textContent: p.l })), ctl = el('div', { className: 'ctl' }), set = v => { obj[p.k] = v; restart(); };
  if (p.t === 'range') { const i = el('input', { type: 'range', min: p.min, max: p.max, step: p.step }), val = el('span', { className: 'val', textContent: obj[p.k] }); i.value = obj[p.k]; i.oninput = () => { val.textContent = i.value; set(+i.value); }; ctl.append(i, val); }
  else if (p.t === 'sel') { const i = el('select'); p.o.forEach(([v, n]) => i.add(new Option(n, v))); i.value = obj[p.k]; i.onchange = () => { set(i.value); renderProps(); }; ctl.append(i); }
  else if (p.t === 'color') { const i = el('input', { type: 'color' }); i.value = obj[p.k]; i.oninput = () => set(i.value); ctl.append(i); }
  else if (p.t === 'check') { const i = el('input', { type: 'checkbox', checked: !!obj[p.k] }); i.onchange = () => set(i.checked); ctl.append(i); }
  else if (p.t === 'text') { const multi = p.k === 'text', i = el(multi ? 'textarea' : 'input', multi ? { rows: 2 } : { type: 'text' }); i.value = obj[p.k] || ''; i.oninput = () => { set(i.value); if (p.k === 'name') renderRows(); }; ctl.append(i); }
  else if (p.t === 'media') {
    const lib = S.library.filter(i => i.type === 'image' || i.type === 'video'), o = [['', '— nenhum —'], ...lib.map(i => [i.src, i.name])];
    if (obj[p.k] && !o.some(x => x[0] === obj[p.k])) { let n = obj[p.k]; try { n = decodeURIComponent(n.split('/').pop()); } catch {} o.push([obj[p.k], n]); }
    const i = el('select'); o.forEach(([v, n]) => i.add(new Option(n, v))); i.value = obj[p.k] || ''; i.onchange = () => set(i.value);
    ctl.append(i, el('button', { className: 'b sm', innerHTML: ic('folder') + 'Procurar', title: 'Escolher um arquivo do computador', onclick: async () => { const f = await api.pickMedia(); if (f) { set(f.src); renderProps(); } } }));
  }
  row.append(ctl); if (p.h) row.append(el('div', { className: 'help', textContent: p.h })); return row;
}
function renderProps() {
  const o = curObj(), T = ST.LT[curType()], box = g('stprops'); box.innerHTML = ''; g('sthead').textContent = 'Ajustes · ' + T.emoji + ' ' + (o.name || T.name);
  if (sel > 0) box.append(propRow({ k: 'name', l: 'Nome da camada', t: 'text', d: '' }, o));
  T.props.concat(sel === 0 ? [] : ST.COMMON).forEach(p => { if (!p.show || p.show(o)) box.append(propRow(p, o)); });
}
function renderRows() {
  const box = g('stlayers'); box.innerHTML = ''; const L = layers();
  for (let i = L.length; i >= 0; i--) {
    const o = i === 0 ? stp.cfg.bg : L[i - 1], T = ST.LT[i === 0 ? 'bg' : o.type], r = el('div', { className: 'lrow' + (sel === i ? ' on' : '') + (o.visible === false ? ' off' : '') }), nm = el('span', { className: 'nm', textContent: T.emoji + ' ' + (o.name || T.name) });
    const btn = (ico, tip, fn) => el('button', { innerHTML: ic(ico), title: tip, onclick: e => { e.stopPropagation(); fn(); } });
    r.append(nm);
    if (i > 0) r.append(
      btn(o.visible === false ? 'eyeoff' : 'eye', 'Mostrar / esconder', () => { o.visible = o.visible === false; renderRows(); restart(); }),
      btn('up', 'Trazer para frente', () => { if (i < L.length) { [L[i - 1], L[i]] = [L[i], L[i - 1]]; sel = i + 1; renderRows(); restart(); } }),
      btn('down', 'Mandar para trás', () => { if (i > 1) { [L[i - 1], L[i - 2]] = [L[i - 2], L[i - 1]]; sel = i - 1; renderRows(); restart(); } }),
      btn('copy', 'Duplicar', () => { L.splice(i, 0, JSON.parse(JSON.stringify(o))); sel = i + 1; renderRows(); renderProps(); restart(); }),
      btn('trash', 'Apagar camada', () => { L.splice(i - 1, 1); sel = Math.min(sel, L.length); renderRows(); renderProps(); restart(); }));
    r.onclick = () => { sel = i; renderRows(); renderProps(); }; box.append(r);
  }
}
function addLayer(type, name, over) { layers().push(ST.make(type, { ...over, name })); sel = layers().length; renderRows(); renderProps(); restart(); }
function buildOnce() {
  if (built) return; built = true;
  ST.PALETTE.forEach(([grp, items]) => { const grid = el('div', { className: 'pgrid' });
    items.forEach(([type, name, emoji, desc, over]) => { const b = el('button', { className: 'pc', title: desc }, el('span', { className: 'em', textContent: emoji }), el('span', {}, el('b', { textContent: name }), el('small', { textContent: desc }))); b.onclick = () => addLayer(type, name, over); grid.append(b); });
    g('stpal').append(el('div', { className: 'pg', textContent: grp }), grid); });
  const sel0 = g('sttpl'); sel0.add(new Option('Começar de um modelo…', '')); ST.TEMPLATES.forEach(([n], i) => sel0.add(new Option(n, i)));
  sel0.onchange = () => { if (sel0.value === '') return; stp.cfg = ST.TEMPLATES[+sel0.value][1](); sel0.value = ''; sel = 0; renderRows(); renderProps(); restart(); toast('Modelo carregado. Mexa nas camadas à vontade!'); };
  g('stcancel').onclick = closeStudio;
  g('stsave').onclick = async () => { stp.name = g('stname').value.trim() || 'Meu wallpaper'; S = await api.saveCustom({ type: 'studio', src: stp.src, name: stp.name, config: stp.cfg }); closeStudio(); render(); toast('Salvo na Biblioteca!'); };
  const c = g('stc'); c.onmousemove = e => { const b = c.getBoundingClientRect(); Cursor.x = (e.clientX - b.left) / b.width; Cursor.y = (e.clientY - b.top) / b.height; Cursor.on = true; };
  c.onmouseleave = () => { Cursor.on = false; Cursor.down = false; }; c.onmousedown = () => { Cursor.down = true; }; c.onmouseup = () => { Cursor.down = false; };
}
function openStudio(item) {
  buildOnce();
  const cfg = !item ? { bg: ST.make('bg', {}), layers: [ST.make('particles', { name: 'Partículas' })] } : item.type === 'studio' ? JSON.parse(JSON.stringify(item.config)) : ST.fromCustom(item.config || {});
  stp = { src: item ? item.src : 'studio:' + Date.now(), name: item ? item.name : 'Meu wallpaper', cfg }; sel = cfg.layers.length;
  g('stname').value = stp.name; renderRows(); renderProps(); g('st').hidden = false; restart();
}
function closeStudio() { clearTimeout(timer); stRun && stRun.stop(); stRun = null; g('st').hidden = true; Cursor.on = false; Cursor.down = false; }
window.openStudio = openStudio; g('create').onclick = () => openStudio(null);

// ---------------- Blocos prontos do modo código ----------------
let group = 'Fundo', counter = 0, undo = [];
function buildTools() {
  const box = g('cetools'); box.innerHTML = ''; const groups = [...new Set(window.SNIPPETS.map(s => s.g))], grid = el('div', { className: 'pgrid' });
  window.SNIPPETS.filter(s => s.g === group).forEach(sn => { const b = el('button', { className: 'pc', title: sn.d }, el('span', { className: 'em', textContent: sn.e }), el('span', {}, el('b', { textContent: sn.n }), el('small', { textContent: sn.d }))); b.onclick = () => addSnippet(sn); grid.append(b); });
  box.append(el('h4', { textContent: 'Ferramentas · clique para adicionar ao código' }),
    el('div', { className: 'chips' }, ...groups.map(n => el('button', { className: 'chip' + (n === group ? ' on' : ''), textContent: n, onclick: () => { group = n; buildTools(); } }))), grid,
    el('div', { className: 'row' }, el('button', { className: 'b sm', innerHTML: ic('up') + 'Desfazer última adição', onclick: () => { if (!undo.length) return toast('Nada para desfazer.'); g('ceta').value = undo.pop(); ceStart(); } })));
}
async function addSnippet(sn) {
  let url = ''; if (sn.pick) { const f = await api.pickMedia(); if (!f) return; url = f.src.replace(/\\/g, '\\\\').replace(/'/g, "\\'"); }
  undo.push(g('ceta').value); g('ceta').value = window.applySnippet(g('ceta').value, sn, ++counter, url); ceStart(); toast('Adicionado: ' + sn.n + '. Veja o resultado na prévia!');
}
const oc = openCode; window.openCode = item => { undo = []; return oc(item); };
buildTools();
})();
