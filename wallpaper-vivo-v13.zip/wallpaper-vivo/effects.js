const Effects = {
  matrix(c) {
    const x = c.getContext('2d'), ch = 'アイウエオカキクケコサシスセソ0123456789'; let drops;
    const init = () => { drops = Array.from({ length: Math.ceil(c.width / 16) }, () => Math.random() * -50); };
    init();
    return { resize: init, frame() {
      x.fillStyle = 'rgba(6,10,14,.14)'; x.fillRect(0, 0, c.width, c.height);
      x.fillStyle = '#8affc7'; x.font = '16px monospace';
      drops.forEach((d, i) => { x.fillText(ch[Math.random() * ch.length | 0], i * 16, d * 16);
        drops[i] = d * 16 > c.height && Math.random() > .975 ? 0 : d + 1; });
    } };
  },
  stars(c) {
    const x = c.getContext('2d'), S = Array.from({ length: 300 }, () => ({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() }));
    return { frame() {
      x.fillStyle = '#05060d'; x.fillRect(0, 0, c.width, c.height);
      for (const s of S) {
        s.z -= .006; if (s.z <= .01) { s.x = Math.random() * 2 - 1; s.y = Math.random() * 2 - 1; s.z = 1; }
        const px = c.width / 2 + s.x / s.z * c.width * .12, py = c.height / 2 + s.y / s.z * c.width * .12;
        x.fillStyle = `rgba(255,255,255,${1 - s.z})`; x.beginPath(); x.arc(px, py, (1 - s.z) * 2 + .3, 0, 7); x.fill();
      }
    } };
  },
  particles(c) {
    const x = c.getContext('2d'), P = Array.from({ length: 80 }, () => ({ x: Math.random(), y: Math.random(), vx: (Math.random() - .5) * 2e-4, vy: (Math.random() - .5) * 2e-4 }));
    return { frame() {
      x.fillStyle = '#10121c'; x.fillRect(0, 0, c.width, c.height);
      const w = c.width, h = c.height, d0 = Math.min(w, h) * .18;
      for (const p of P) { p.x = (p.x + p.vx * 16 + 1) % 1; p.y = (p.y + p.vy * 16 + 1) % 1; }
      for (let i = 0; i < P.length; i++) {
        x.fillStyle = '#ffa48a'; x.fillRect(P[i].x * w - 1.5, P[i].y * h - 1.5, 3, 3);
        for (let j = i + 1; j < P.length; j++) {
          const d = Math.hypot((P[i].x - P[j].x) * w, (P[i].y - P[j].y) * h);
          if (d < d0) { x.strokeStyle = `rgba(138,164,255,${1 - d / d0})`; x.beginPath(); x.moveTo(P[i].x * w, P[i].y * h); x.lineTo(P[j].x * w, P[j].y * h); x.stroke(); }
        }
      }
    } };
  },
  aurora(c) {
    const x = c.getContext('2d'), cols = ['#3dffb5', '#6b8cff', '#c06bff'];
    return { frame(t) {
      x.globalCompositeOperation = 'source-over'; x.fillStyle = '#070912'; x.fillRect(0, 0, c.width, c.height);
      x.globalCompositeOperation = 'lighter';
      cols.forEach((col, k) => {
        const g = x.createLinearGradient(0, c.height * .2, 0, c.height * .8); g.addColorStop(0, 'transparent'); g.addColorStop(.5, col + '88'); g.addColorStop(1, 'transparent');
        x.fillStyle = g; x.beginPath(); x.moveTo(0, c.height);
        for (let i = 0; i <= c.width; i += 20) x.lineTo(i, c.height * (.45 + k * .08) + Math.sin(i * .003 + t * .0004 * (k + 1) + k) * c.height * .12);
        x.lineTo(c.width, c.height); x.fill();
      });
    } };
  },
  waves(c) {
    const x = c.getContext('2d');
    return { frame(t) {
      const g = x.createLinearGradient(0, 0, 0, c.height); g.addColorStop(0, '#1b2a4a'); g.addColorStop(1, '#0b1020');
      x.fillStyle = g; x.fillRect(0, 0, c.width, c.height);
      for (let k = 0; k < 5; k++) {
        x.fillStyle = `hsla(${200 + k * 12},70%,${40 + k * 5}%,.35)`; x.beginPath(); x.moveTo(0, c.height);
        for (let i = 0; i <= c.width; i += 12) x.lineTo(i, c.height * (.55 + k * .07) + Math.sin(i * .004 + t * .0007 * (1 + k * .3) + k * 2) * 26);
        x.lineTo(c.width, c.height); x.fill();
      }
    } };
  }
};
const EffectNames = { matrix: 'Chuva digital', stars: 'Viagem estelar', particles: 'Constelação', aurora: 'Aurora', waves: 'Ondas' };
function runEffect(name, canvas, fps = 30) { return runLoop(Effects[name](canvas), canvas, fps); }
function runCustom(cfg, canvas, fps = 30) { return runLoop(makeCustom(cfg, canvas), canvas, fps); }
function runLoop(e, canvas, fps = 30) {
  let id, last = 0, paused = false;
  const loop = t => { id = requestAnimationFrame(loop); if (paused || t - last < 1000 / fps) return; last = t; e.frame(t); };
  id = requestAnimationFrame(loop);
  return { stop: () => { cancelAnimationFrame(id); e.stop && e.stop(); }, pause: v => { paused = v; e.pause && e.pause(v); },
    resize: (w, h) => { canvas.width = w; canvas.height = h; e.resize && e.resize(); } };
}
Object.assign(Effects, {
  rain(c) {
    const x = c.getContext('2d'), D = Array.from({ length: 220 }, () => ({ x: Math.random(), y: Math.random(), v: .012 + Math.random() * .02, l: 10 + Math.random() * 18 }));
    return { frame() {
      x.fillStyle = 'rgba(9,13,24,.4)'; x.fillRect(0, 0, c.width, c.height); x.strokeStyle = 'rgba(150,180,255,.55)'; x.beginPath();
      for (const d of D) { d.y += d.v; if (d.y > 1) { d.y = -.05; d.x = Math.random(); } const px = d.x * c.width, py = d.y * c.height; x.moveTo(px, py); x.lineTo(px - d.l * .15, py + d.l); }
      x.stroke();
    } };
  },
  snow(c) {
    const x = c.getContext('2d'), F = Array.from({ length: 160 }, () => ({ x: Math.random(), y: Math.random(), r: 1 + Math.random() * 3, v: .0006 + Math.random() * .0014, p: Math.random() * 6 }));
    return { frame(t) {
      x.fillStyle = '#0d1424'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = 'rgba(255,255,255,.85)';
      for (const f of F) { f.y += f.v * 16; if (f.y > 1.02) { f.y = -.02; f.x = Math.random(); } x.beginPath(); x.arc(f.x * c.width + Math.sin(t * .001 + f.p) * 20, f.y * c.height, f.r, 0, 7); x.fill(); }
    } };
  },
  fireflies(c) {
    const x = c.getContext('2d'), F = Array.from({ length: 50 }, () => ({ x: Math.random(), y: Math.random(), a: Math.random() * 6, s: .2 + Math.random() * .6 }));
    return { frame(t) {
      x.fillStyle = '#07100d'; x.fillRect(0, 0, c.width, c.height); x.globalCompositeOperation = 'lighter';
      for (const f of F) {
        f.a += .003 * f.s; f.x = (f.x + Math.cos(f.a) * .0006 + 1) % 1; f.y = (f.y + Math.sin(f.a * 1.3) * .0006 + 1) % 1;
        const px = f.x * c.width, py = f.y * c.height, r = 22, al = .35 + .65 * Math.abs(Math.sin(t * .001 * f.s + f.a)), g = x.createRadialGradient(px, py, 0, px, py, r);
        g.addColorStop(0, `rgba(220,255,140,${al})`); g.addColorStop(1, 'rgba(220,255,140,0)'); x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2);
      }
      x.globalCompositeOperation = 'source-over';
    } };
  },
  grid(c) {
    const x = c.getContext('2d');
    return { frame(t) {
      const w = c.width, h = c.height, hz = h * .55, g = x.createLinearGradient(0, 0, 0, hz); g.addColorStop(0, '#1a0b3a'); g.addColorStop(1, '#ff5fa2');
      x.fillStyle = g; x.fillRect(0, 0, w, hz); x.fillStyle = '#ffb36b'; x.beginPath(); x.arc(w / 2, hz - h * .02, h * .17, Math.PI, 0); x.fill();
      x.fillStyle = '#0a0618'; x.fillRect(0, hz, w, h - hz); x.strokeStyle = '#ff5fd2'; x.lineWidth = 1.5; x.beginPath();
      for (let i = -20; i <= 20; i++) { x.moveTo(w / 2 + i * w * .01, hz); x.lineTo(w / 2 + i * w * .12, h); }
      const p = (t * .0003) % 1; for (let k = 0; k < 12; k++) { const y = hz + ((k + p) / 12) ** 2.2 * (h - hz); x.moveTo(0, y); x.lineTo(w, y); }
      x.stroke();
    } };
  },
  lava(c) {
    const x = c.getContext('2d'), B = Array.from({ length: 6 }, (_, i) => ({ a: i * 1.7, s: .0002 + i * .00008, h: i * 55 + 260 }));
    return { frame(t) {
      x.globalCompositeOperation = 'source-over'; x.fillStyle = '#14061f'; x.fillRect(0, 0, c.width, c.height); x.globalCompositeOperation = 'lighter';
      for (const b of B) {
        const px = c.width * (.5 + .38 * Math.sin(t * b.s + b.a)), py = c.height * (.5 + .38 * Math.cos(t * b.s * 1.3 + b.a * 2)), r = Math.min(c.width, c.height) * .32, g = x.createRadialGradient(px, py, 0, px, py, r);
        g.addColorStop(0, `hsla(${b.h},90%,60%,.65)`); g.addColorStop(1, `hsla(${b.h},90%,60%,0)`); x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2);
      }
      x.globalCompositeOperation = 'source-over';
    } };
  }
});
Object.assign(EffectNames, { rain: 'Chuva', snow: 'Neve', fireflies: 'Vaga-lumes', grid: 'Pôr do sol retrô', lava: 'Lava' });

const AudioIn = { on: false, freq: null, wave: null };
const audioBin = (i, n, t) => AudioIn.on ? AudioIn.freq[Math.floor(i / n * 80)] / 255 : .28 + .22 * Math.sin(t * .002 + i * .35);
Object.assign(Effects, {
  bars(c) {
    const x = c.getContext('2d');
    return { frame(t) {
      const w = c.width, h = c.height, n = 48, bw = w / n; x.fillStyle = '#0b0d16'; x.fillRect(0, 0, w, h);
      for (let i = 0; i < n; i++) { const v = audioBin(i, n, t), bh = v * h * .7; x.fillStyle = `hsl(${200 + i * 3},85%,${50 + v * 25}%)`; x.fillRect(i * bw + bw * .15, h - bh, bw * .7, bh); }
    } };
  },
  ring(c) {
    const x = c.getContext('2d');
    return { frame(t) {
      const w = c.width, h = c.height, n = 96, m = Math.min(w, h), r0 = m * .2; x.fillStyle = '#0b0d16'; x.fillRect(0, 0, w, h); x.lineWidth = Math.max(2, m * .006);
      for (let i = 0; i < n; i++) {
        const a = i / n * Math.PI * 2 + t * .0002, k = i < n / 2 ? i : n - 1 - i, v = audioBin(k, n / 2, t), r1 = r0 + v * m * .3;
        x.strokeStyle = `hsl(${i * 3.5 + t * .02},85%,${55 + v * 20}%)`; x.beginPath();
        x.moveTo(w / 2 + Math.cos(a) * r0, h / 2 + Math.sin(a) * r0); x.lineTo(w / 2 + Math.cos(a) * r1, h / 2 + Math.sin(a) * r1); x.stroke();
      }
    } };
  },
  soundwave(c) {
    const x = c.getContext('2d');
    return { frame(t) {
      const w = c.width, h = c.height; x.fillStyle = 'rgba(8,10,20,.35)'; x.fillRect(0, 0, w, h); x.lineWidth = Math.max(2, h * .004);
      [['#8aa4ff', 1], ['#ffa48a', .6]].forEach(([col, amp], k) => {
        x.strokeStyle = col; x.beginPath();
        for (let i = 0; i <= 128; i++) {
          const v = AudioIn.on ? AudioIn.wave[Math.floor(i / 128 * 255)] / 128 - 1 : Math.sin(i * .12 + t * .003 + k) * .35;
          const px = i / 128 * w, py = h / 2 + v * h * .4 * amp; i ? x.lineTo(px, py) : x.moveTo(px, py);
        }
        x.stroke();
      });
    } };
  }
});
Object.assign(EffectNames, { bars: 'Barras de som', ring: 'Anel de som', soundwave: 'Onda de som' });

const Cursor = { x: .5, y: .5, down: false, on: false };
const cur = t => Cursor.on ? Cursor : { x: .5 + .32 * Math.sin(t * .0007), y: .5 + .28 * Math.sin(t * .0011 + 1), down: false };
Object.assign(Effects, {
  trail(c) {
    const x = c.getContext('2d'), P = [];
    return { frame(t) {
      const w = c.width, h = c.height, m = cur(t);
      x.globalCompositeOperation = 'source-over'; x.fillStyle = 'rgba(8,9,18,.22)'; x.fillRect(0, 0, w, h); x.globalCompositeOperation = 'lighter';
      const s = m.down ? 6 : 1.5;
      for (let i = 0; i < (m.down ? 6 : 2); i++) P.push({ x: m.x * w, y: m.y * h, vx: (Math.random() - .5) * s, vy: (Math.random() - .5) * s, l: 1, hu: (t * .05 + i * 20) % 360 });
      if (P.length > 900) P.splice(0, P.length - 900);
      for (let i = P.length - 1; i >= 0; i--) {
        const p = P[i]; p.x += p.vx; p.y += p.vy; p.l -= .018; if (p.l <= 0) { P.splice(i, 1); continue; }
        x.fillStyle = `hsla(${p.hu},90%,60%,${p.l * .8})`; x.beginPath(); x.arc(p.x, p.y, 2 + p.l * 7, 0, 7); x.fill();
      }
      x.globalCompositeOperation = 'source-over';
    } };
  },
  magnet(c) {
    const x = c.getContext('2d'), P = Array.from({ length: 260 }, () => ({ x: Math.random(), y: Math.random(), vx: 0, vy: 0 }));
    return { frame(t) {
      const w = c.width, h = c.height, m = cur(t); x.fillStyle = 'rgba(10,12,22,.3)'; x.fillRect(0, 0, w, h);
      for (const p of P) {
        const dx = m.x - p.x, dy = (m.y - p.y) * h / w, d = Math.hypot(dx, dy) + .001, f = (m.down ? -1 : 1) * .0002 / d;
        p.vx = (p.vx + dx / d * f) * .96; p.vy = (p.vy + dy / d * f * w / h) * .96;
        p.x = (p.x + p.vx + 1) % 1; p.y = (p.y + p.vy + 1) % 1;
        x.fillStyle = `hsl(${200 + d * 200},85%,65%)`; x.fillRect(p.x * w, p.y * h, 2.5, 2.5);
      }
    } };
  },
  ripples(c) {
    const x = c.getContext('2d'), R = []; let last = 0, was = false;
    return { frame(t) {
      const w = c.width, h = c.height, m = cur(t); x.fillStyle = '#0a1424'; x.fillRect(0, 0, w, h);
      if (t - last > (m.down ? 120 : 450)) { last = t; R.push({ x: m.x * w, y: m.y * h, r: 0, big: m.down }); }
      if (m.down && !was) R.push({ x: m.x * w, y: m.y * h, r: 0, big: true }); was = m.down;
      for (let i = R.length - 1; i >= 0; i--) {
        const q = R[i]; q.r += q.big ? 6 : 3.5; const a = 1 - q.r / (Math.min(w, h) * (q.big ? .7 : .4)); if (a <= 0) { R.splice(i, 1); continue; }
        x.strokeStyle = `rgba(140,200,255,${a})`; x.lineWidth = 2 + a * 3; x.beginPath(); x.arc(q.x, q.y, q.r, 0, 7); x.stroke();
      }
    } };
  },
  dots(c) {
    const x = c.getContext('2d');
    return { frame(t) {
      const w = c.width, h = c.height, m = cur(t), s = Math.max(28, Math.round(w / 50)), R = Math.min(w, h) * .25; x.fillStyle = '#0c0e18'; x.fillRect(0, 0, w, h);
      for (let gy = s / 2; gy < h; gy += s) for (let gx = s / 2; gx < w; gx += s) {
        const dx = gx - m.x * w, dy = gy - m.y * h, d = Math.hypot(dx, dy), k = Math.max(0, 1 - d / R), push = k * k * s * .9 * (m.down ? -1 : 1);
        x.fillStyle = `hsl(${210 + k * 150},80%,${45 + k * 30}%)`; x.beginPath(); x.arc(gx + dx / (d || 1) * push, gy + dy / (d || 1) * push, 2 + k * s * .28, 0, 7); x.fill();
      }
    } };
  }
});
Object.assign(EffectNames, { trail: 'Rastro de luz', magnet: 'Partículas magnéticas', ripples: 'Ondas na água', dots: 'Pontos reativos' });

// ---- Motor do criador de wallpapers ----
const CUSTOM_DEF = { bg1: '#0b0d16', bg2: '#1a1040', trails: 25, shape: 'dot', count: 140, size: 3, speed: 1, hue: 210, hueRange: 60, light: 62,
  link: false, cursor: 'attract', cursorForce: 1, click: true, audio: 'both', audioGain: 1, spectrum: 'none' };
const audioLevel = t => { if (!AudioIn.on) return .3 + .25 * Math.sin(t * .003); let s = 0; for (let i = 0; i < 24; i++) s += AudioIn.freq[i]; return s / 24 / 255; };
function makeCustom(cfg0, c) {
  const C = { ...CUSTOM_DEF, ...cfg0 }, x = c.getContext('2d');
  const P = Array.from({ length: C.count }, () => ({ x: Math.random(), y: Math.random(), vx: 0, vy: 0, h: Math.random() * 2 - 1, s: .6 + Math.random() * .8 }));
  let was = false, lvl = 0;
  return { frame(t) {
    const w = c.width, h = c.height, m = cur(t), r = w / h, u = Math.max(.35, w / 1600);
    lvl += (audioLevel(t) - lvl) * .3; const a = Math.min(1, lvl * C.audioGain);
    const sz = C.audio === 'size' || C.audio === 'both' ? 1 + a * 2.2 : 1, sp = C.audio === 'speed' || C.audio === 'both' ? 1 + a * 3 : 1, lg = C.audio !== 'none' ? a * 18 : 0;
    const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, C.bg1); g.addColorStop(1, C.bg2);
    x.globalAlpha = 1 - C.trails / 100 * .95; x.fillStyle = g; x.fillRect(0, 0, w, h); x.globalAlpha = 1;
    const F = C.cursorForce * .00005, burst = m.down && !was; was = m.down;
    for (const p of P) {
      const dx = m.x - p.x, dy = (m.y - p.y) / r, d = Math.hypot(dx, dy) + .001, k = F / (d + .12);
      if (C.cursor === 'attract') { p.vx += dx / d * k; p.vy += dy / d * k * r; }
      else if (C.cursor === 'repel') { const q = d < .25 ? k * 3 : 0; p.vx -= dx / d * q; p.vy -= dy / d * q * r; }
      else if (C.cursor === 'orbit') { p.vx += -dy / d * k * 1.2 + dx / d * k * .3; p.vy += (dx / d * k * 1.2 + dy / d * k * .3) * r; }
      else if (C.cursor === 'follow') { p.vx += dx * F * 6; p.vy += dy * r * F * 6; }
      if (C.click && burst && d < .4) { p.vx -= dx / d * .003; p.vy -= dy / d * .003 * r; }
      p.vx = (p.vx + (Math.random() - .5) * 4e-5) * .985; p.vy = (p.vy + (Math.random() - .5) * 4e-5) * .985;
      p.x = (p.x + p.vx * sp * C.speed + 1) % 1; p.y = (p.y + p.vy * sp * C.speed + 1) % 1;
    }
    x.lineCap = 'round';
    for (const p of P) {
      const px = p.x * w, py = p.y * h, col = `hsla(${C.hue + p.h * C.hueRange},85%,${C.light + lg}%,.9)`, rad = C.size * p.s * sz * u;
      if (C.shape === 'line') { x.strokeStyle = col; x.lineWidth = Math.max(1, rad * .6); x.beginPath(); x.moveTo(px, py); x.lineTo(px - p.vx * w * 14, py - p.vy * h * 14); x.stroke(); }
      else if (C.shape === 'ring') { x.strokeStyle = col; x.lineWidth = Math.max(1, rad * .3); x.beginPath(); x.arc(px, py, rad * 1.6, 0, 7); x.stroke(); }
      else { x.fillStyle = col; x.beginPath(); x.arc(px, py, rad, 0, 7); x.fill(); }
    }
    if (C.link) {
      x.lineWidth = 1; const L = Math.min(w, h) * .12;
      for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) {
        const d = Math.hypot((P[i].x - P[j].x) * w, (P[i].y - P[j].y) * h);
        if (d < L) { x.strokeStyle = `hsla(${C.hue},80%,70%,${(1 - d / L) * .5})`; x.beginPath(); x.moveTo(P[i].x * w, P[i].y * h); x.lineTo(P[j].x * w, P[j].y * h); x.stroke(); }
      }
    }
    if (C.spectrum === 'bars') {
      const n = 48, bw = w / n;
      for (let i = 0; i < n; i++) { const v = audioBin(i, n, t); x.fillStyle = `hsla(${C.hue + i * 2},85%,60%,.55)`; x.fillRect(i * bw + bw * .15, h - v * h * .35, bw * .7, v * h * .35); }
    } else if (C.spectrum === 'ring') {
      const n = 80, m0 = Math.min(w, h), r0 = m0 * .18; x.lineWidth = Math.max(2, m0 * .005);
      for (let i = 0; i < n; i++) {
        const an = i / n * Math.PI * 2, v = audioBin(i < n / 2 ? i : n - 1 - i, n / 2, t), r1 = r0 + v * m0 * .25;
        x.strokeStyle = `hsla(${C.hue + i * 3},85%,65%,.7)`; x.beginPath(); x.moveTo(w / 2 + Math.cos(an) * r0, h / 2 + Math.sin(an) * r0); x.lineTo(w / 2 + Math.cos(an) * r1, h / 2 + Math.sin(an) * r1); x.stroke();
      }
    }
  } };
}

// ---- Modo código: o usuário escreve setup(io) e draw(ctx, io) ----
function runCode(src, canvas, fps = 30) { return runLoop(makeCode(src, canvas), canvas, fps); }
function makeCode(src, c) {
  const x = c.getContext('2d'); let fns = null, last = 0, lastErr = null;
  const io = { w: c.width, h: c.height, t: 0, dt: 16, TAU: Math.PI * 2, rand: (a = 0, b = 1) => a + Math.random() * (b - a),
    mouse: { x: 0, y: 0, nx: .5, ny: .5, down: false, pressed: false, on: false },
    audio: { on: false, level: 0, bass: 0, mid: 0, treble: 0, freq: new Array(64).fill(0), wave: new Array(128).fill(0) } };
  const report = e => { const msg = e ? (e.message || String(e)) : ''; if (msg !== lastErr) { lastErr = msg; c.dispatchEvent(new CustomEvent('codeerror', { detail: msg })); } };
  const run = f => { try { f(); report(null); } catch (e) { report(e); } };
  run(() => {
    fns = new Function('io', src + '\n;return { setup: typeof setup === "function" ? setup : null, draw: typeof draw === "function" ? draw : null };')(io);
    if (fns.setup) fns.setup(io);
  });
  return {
    resize() { io.w = c.width; io.h = c.height; if (fns && fns.setup) run(() => fns.setup(io)); },
    frame(t) {
      io.w = c.width; io.h = c.height; io.dt = last ? Math.min(100, t - last) : 16; last = t; io.t = t;
      const m = cur(t), M = io.mouse; M.nx = m.x; M.ny = m.y; M.x = m.x * io.w; M.y = m.y * io.h; M.pressed = m.down && !M.down; M.down = m.down; M.on = !!Cursor.on;
      const A = io.audio, on = AudioIn.on, avg = (a, b) => { let s = 0; for (let i = a; i < b; i++) s += A.freq[i]; return s / (b - a); };
      A.on = on;
      for (let i = 0; i < 64; i++) A.freq[i] = on ? AudioIn.freq[i] / 255 : Math.max(0, .3 + .2 * Math.sin(t * .002 + i * .3) - i * .003);
      for (let i = 0; i < 128; i++) A.wave[i] = on ? AudioIn.wave[i * 2] / 128 - 1 : Math.sin(i * .15 + t * .003) * .3;
      A.bass = avg(0, 6); A.mid = avg(6, 26); A.treble = avg(26, 64); A.level = avg(0, 24);
      if (fns && fns.draw) { x.save(); run(() => fns.draw(x, io)); x.restore(); }
    } };
}
