// Atualização remota via GitHub Releases (electron-updater) com plano B: só avisar e abrir a página da versão.
const { app } = require('electron');
const pkg = require('./package.json');
const pub = ((pkg.build || {}).publish || [])[0] || {};
let au = null; try { au = require('electron-updater').autoUpdater; } catch {}
const cmp = (a, b) => { const p = s => String(s).replace(/^v/, '').split('.').map(n => parseInt(n, 10) || 0); const x = p(a), y = p(b);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? 1 : -1; return 0; };
const configured = () => !!(pub.owner && pub.repo && pub.owner !== 'SEU-USUARIO');
let wired = false;
async function check(send) {
  if (!configured()) return send({ state: 'off', text: 'Atualizações ainda não configuradas (veja o LEIAME).' });
  try {
    if (au && app.isPackaged) {
      if (!wired) {
        wired = true; au.autoDownload = true; au.autoInstallOnAppQuit = true;
        au.on('checking-for-update', () => send({ state: 'checking', text: 'Verificando…' }));
        au.on('update-available', i => send({ state: 'downloading', text: 'Baixando a versão ' + i.version + '…' }));
        au.on('update-not-available', () => send({ state: 'ok', text: 'Você já está na versão mais recente.' }));
        au.on('download-progress', p => send({ state: 'downloading', text: 'Baixando… ' + Math.round(p.percent) + '%' }));
        au.on('update-downloaded', i => send({ state: 'ready', text: 'Versão ' + i.version + ' pronta. Reinicie para instalar.' }));
        au.on('error', e => send({ state: 'error', text: 'Não foi possível atualizar: ' + String((e && e.message) || e).slice(0, 120) }));
      }
      await au.checkForUpdates(); return;
    }
    const r = await fetch('https://api.github.com/repos/' + pub.owner + '/' + pub.repo + '/releases/latest', { headers: { 'User-Agent': 'WallpaperVivo', Accept: 'application/vnd.github+json' } });
    if (r.status === 404) return send({ state: 'ok', text: 'Nenhuma versão publicada ainda.' });
    if (!r.ok) throw new Error('GitHub respondeu ' + r.status);
    const j = await r.json(), v = String(j.tag_name || '').replace(/^v/, '');
    send(cmp(v, app.getVersion()) > 0 ? { state: 'available', text: 'Versão ' + v + ' disponível.', url: j.html_url } : { state: 'ok', text: 'Você já está na versão mais recente.' });
  } catch (e) { send({ state: 'error', text: 'Não foi possível verificar: ' + String(e.message || e).slice(0, 120) }); }
}
const install = () => { if (au) au.quitAndInstall(); };
module.exports = { check, install, cmp, configured };
