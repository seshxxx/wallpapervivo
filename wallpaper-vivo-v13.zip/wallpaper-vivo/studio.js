// ===== Estúdio de camadas: motor (roda na janela do wallpaper e na prévia do painel) =====
(() => {
const TAU = Math.PI * 2, rnd = (a, b) => a + Math.random() * (b - a), clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v)), U = w => Math.max(.4, w / 1600);
const hexRgb = h => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''), n = m ? parseInt(m[1], 16) : 0xffffff; return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
const rgba = (h, a = 1) => { const [r, g, b] = hexRgb(h); return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')'; };
const hexHsl = h => { const [r, g, b] = hexRgb(h).map(v => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn; let hh = 0, s = 0;
  if (d) { s = d / (1 - Math.abs(2 * l - 1)); hh = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh *= 60; if (hh < 0) hh += 360; } return [hh, s * 100, l * 100]; };
const hslHex = (h, s, l) => { s /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l), f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return '#' + [f(0), f(8), f(4)].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join(''); };

// ---- entradas compartilhadas (tempo, cursor, som) ----
function makeIO(c) {
  const io = { w: c.width, h: c.height, t: 0, dt: 16, mouse: { x: 0, y: 0, nx: .5, ny: .5, down: false, pressed: false, on: false },
    audio: { on: false, level: 0, bass: 0, mid: 0, treble: 0, freq: new Array(64).fill(0), wave: new Array(128).fill(0) } };
  let last = 0; const avg = (a, b) => { let s = 0; for (let i = a; i < b; i++) s += io.audio.freq[i]; return s / (b - a); };
  return { io, tick(t) {
    io.w = c.width; io.h = c.height; io.dt = last ? Math.min(100, t - last) : 16; last = t; io.t = t;
    const m = cur(t), M = io.mouse; M.nx = m.x; M.ny = m.y; M.x = m.x * io.w; M.y = m.y * io.h; M.pressed = !!m.down && !M.down; M.down = !!m.down; M.on = !!Cursor.on;
    const A = io.audio, on = AudioIn.on; A.on = on;
    for (let i = 0; i < 64; i++) A.freq[i] = on ? AudioIn.freq[i] / 255 : Math.max(0, .3 + .2 * Math.sin(t * .002 + i * .3) - i * .003);
    for (let i = 0; i < 128; i++) A.wave[i] = on ? AudioIn.wave[i * 2] / 128 - 1 : Math.sin(i * .15 + t * .003) * .3;
    A.bass = avg(0, 6); A.mid = avg(6, 26); A.treble = avg(26, 64); A.level = avg(0, 24);
  } };
}
// ---- mídia (imagem, GIF animado, vídeo) ----
const MEDIA = new Map();
function loadMedia(url) {
  if (!url) return null; if (MEDIA.has(url)) return MEDIA.get(url);
  const ext = ((url.split('?')[0].match(/\.(\w+)$/) || [])[1] || '').toLowerCase(), m = { ready: false, w: 0, h: 0, el: null, video: null, refs: 0 };
  if (ext === 'mp4' || ext === 'webm') {
    const v = document.createElement('video'); Object.assign(v, { src: url, muted: true, loop: true, playsInline: true, autoplay: true });
    v.addEventListener('loadeddata', () => { m.ready = true; m.w = v.videoWidth; m.h = v.videoHeight; }); m.el = m.video = v;
  } else {
    const im = new Image(); im.addEventListener('load', () => { m.ready = true; m.w = im.naturalWidth; m.h = im.naturalHeight; }); im.src = url; m.el = im;
    if (ext === 'gif' || ext === 'webp') { im.style.cssText = 'position:fixed;left:0;top:0;width:2px;height:2px;opacity:.01;pointer-events:none;z-index:-1'; document.body.appendChild(im); } // no DOM, para o GIF animar
  }
  MEDIA.set(url, m); return m;
}
const fitRect = (m, w, h, mode) => { const s = (mode === 'cover' ? Math.max : Math.min)(w / m.w, h / m.h), dw = m.w * s, dh = m.h * s; return [(w - dw) / 2, (h - dh) / 2, dw, dh]; };

// ---- descrição das camadas ----
const R = (k, l, min, max, d, step = 1, h = '') => ({ k, l, t: 'range', min, max, d, step, h }), S = (k, l, o, d, h = '') => ({ k, l, t: 'sel', o, d, h }),
  C = (k, l, d, h = '') => ({ k, l, t: 'color', d, h }), K = (k, l, d, h = '') => ({ k, l, t: 'check', d, h }), T = (k, l, d, h = '') => ({ k, l, t: 'text', d, h }), M = (k, l, h = '') => ({ k, l, t: 'media', d: '', h });
const when = (p, f) => ({ ...p, show: f });
const FONTS = [['Outfit', 'Outfit (moderna)'], ['Bahnschrift', 'Bahnschrift (técnica)'], ['Segoe UI', 'Segoe UI'], ['Impact', 'Impact (grossa)'], ['Georgia', 'Georgia (com serifa)'], ['Courier New', 'Courier (máquina de escrever)'], ['JetBrains Mono', 'JetBrains Mono (código)'], ['Brush Script MT', 'Cursiva'], ['Comic Sans MS', 'Comic Sans']];
const COMMON = [R('opacity', 'Transparência (100 = sólido)', 0, 100, 100, 1, 'Diminua para a camada ficar mais fraquinha'),
  S('blend', 'Mistura de cor', [['source-over', 'Normal'], ['lighter', 'Brilho (soma as luzes)'], ['screen', 'Clarear'], ['multiply', 'Escurecer'], ['overlay', 'Contraste']], 'source-over', 'Como esta camada se mistura com as de baixo')];
const LT = {}, def = (type, name, emoji, props, make) => { LT[type] = { name, emoji, props, make }; };
const CH = 'アイウエオカキクケコサシスセソ0123456789ABCDEF';

def('bg', 'Fundo', '🎨', [
  S('mode', 'Tipo de fundo', [['solid', 'Cor sólida'], ['gradient', 'Degradê'], ['media', 'Imagem, GIF ou vídeo']], 'gradient'), C('c1', 'Cor 1 (de cima)', '#0b0d16'),
  when(C('c2', 'Cor 2 (de baixo)', '#1a1040'), l => l.mode === 'gradient'), when(R('angle', 'Direção do degradê', 0, 360, 180, 5, '180 = de cima para baixo'), l => l.mode === 'gradient'),
  when(M('media', 'Arquivo do fundo'), l => l.mode === 'media'),
  when(R('trails', 'Rastro de movimento', 0, 90, 0, 1, 'Deixa um rastro atrás das animações. Não funciona com imagem ou vídeo de fundo.'), l => l.mode !== 'media')],
  (L, c, use) => { const m = L.mode === 'media' && L.media ? use(L.media) : null; let first = true, lw = 0;
    return { frame(x, io) { const w = io.w, h = io.h; if (w !== lw) { first = true; lw = w; }
      if (L.mode === 'media') { if (m && m.ready) x.drawImage(m.el, ...fitRect(m, w, h, 'cover')); else { x.fillStyle = L.c1; x.fillRect(0, 0, w, h); } return; }
      let f = L.c1; if (L.mode === 'gradient') { const a = L.angle * Math.PI / 180, r = Math.hypot(w, h) / 2, dx = Math.sin(a) * r, dy = -Math.cos(a) * r, g = x.createLinearGradient(w / 2 - dx, h / 2 - dy, w / 2 + dx, h / 2 + dy); g.addColorStop(0, L.c1); g.addColorStop(1, L.c2); f = g; }
      x.globalAlpha = first ? 1 : 1 - L.trails / 100 * .95; first = false; x.fillStyle = f; x.fillRect(0, 0, w, h); } }; });

def('media', 'Imagem, GIF ou vídeo', '🖼️', [M('media', 'Arquivo', 'Escolha da sua Biblioteca ou procure no computador'),
  S('fit', 'Tamanho', [['free', 'Livre (use o controle abaixo)'], ['cover', 'Preencher a tela'], ['contain', 'Caber na tela']], 'free'), when(R('size', 'Largura (% da tela)', 2, 300, 40), l => l.fit === 'free'),
  R('x', 'Posição horizontal', 0, 100, 50), R('y', 'Posição vertical', 0, 100, 50), R('rot', 'Inclinação', -180, 180, 0), K('flip', 'Espelhar', false),
  R('float', 'Flutuar', 0, 100, 0, 1, 'Sobe e desce suavemente'), R('parallax', 'Seguir o cursor (profundidade)', 0, 100, 0, 1, 'Mexe um pouco acompanhando o mouse'),
  R('pulse', 'Pulsar com a música', 0, 100, 0, 1, 'Cresce de leve com os graves'), R('spin', 'Girar', -100, 100, 0, 1, 'Gira o tempo todo. Negativo gira ao contrário.')],
  (L, c, use) => { const m = L.media ? use(L.media) : null;
    return { frame(x, io) { if (!m || !m.ready) return; const w = io.w, h = io.h, mo = io.mouse, sec = io.t / 1000; let dw, dh;
      if (L.fit === 'free') { dw = w * L.size / 100; dh = dw * m.h / m.w; } else { [, , dw, dh] = fitRect(m, w, h, L.fit); }
      const pu = 1 + io.audio.bass * L.pulse / 100 * .35, k = L.parallax / 100;
      x.translate(w * L.x / 100 + (mo.nx - .5) * k * w * .08, h * L.y / 100 + Math.sin(sec * 1.4) * L.float / 100 * h * .05 + (mo.ny - .5) * k * h * .08);
      x.rotate((L.rot + sec * L.spin * 1.8) * Math.PI / 180); x.scale(pu * (L.flip ? -1 : 1), pu); x.drawImage(m.el, -dw / 2, -dh / 2, dw, dh); } }; });

def('particles', 'Partículas', '🫧', [S('shape', 'Forma', [['dot', 'Pontos'], ['line', 'Riscos'], ['ring', 'Anéis']], 'dot'), R('count', 'Quantidade', 10, 400, 120), R('size', 'Tamanho', 1, 14, 3, .5), R('speed', 'Velocidade', .2, 4, 1, .1),
  C('color', 'Cor', '#8b9cff'), R('hueRange', 'Variação de cor', 0, 180, 50, 1, '0 = todas iguais'), K('link', 'Ligar com linhas', false),
  S('cursor', 'Quando o cursor se mexe', [['none', 'Ignorar'], ['attract', 'Atrair'], ['repel', 'Repelir'], ['orbit', 'Girar em volta'], ['follow', 'Seguir']], 'attract'), R('cursorForce', 'Força do cursor', .2, 4, 1, .1),
  K('click', 'Clique explode', true), S('audio', 'Quando toca música', [['none', 'Ignorar'], ['size', 'Aumentar o tamanho'], ['speed', 'Acelerar'], ['both', 'Tamanho e velocidade']], 'both'), R('audioGain', 'Sensibilidade ao som', .3, 3, 1, .1)],
  (L, c) => { const P = Array.from({ length: L.count }, () => ({ x: Math.random(), y: Math.random(), vx: 0, vy: 0, h: Math.random() * 2 - 1, s: .6 + Math.random() * .8 })), [H, Sa, Li] = hexHsl(L.color); let lvl = 0;
    return { frame(x, io) { const w = io.w, h = io.h, m = io.mouse, r = w / h, u = U(w); lvl += (io.audio.level - lvl) * .3; const a = clamp(lvl * L.audioGain),
        sz = L.audio === 'size' || L.audio === 'both' ? 1 + a * 2.2 : 1, sp = L.audio === 'speed' || L.audio === 'both' ? 1 + a * 3 : 1, lg = L.audio !== 'none' ? a * 15 : 0, F = L.cursorForce * .00005;
      for (const p of P) { const dx = m.nx - p.x, dy = (m.ny - p.y) / r, d = Math.hypot(dx, dy) + .001, k = F / (d + .12);
        if (L.cursor === 'attract') { p.vx += dx / d * k; p.vy += dy / d * k * r; } else if (L.cursor === 'repel') { const q = d < .25 ? k * 3 : 0; p.vx -= dx / d * q; p.vy -= dy / d * q * r; }
        else if (L.cursor === 'orbit') { p.vx += -dy / d * k * 1.2 + dx / d * k * .3; p.vy += (dx / d * k * 1.2 + dy / d * k * .3) * r; } else if (L.cursor === 'follow') { p.vx += dx * F * 6; p.vy += dy * r * F * 6; }
        if (L.click && m.pressed && d < .4) { p.vx -= dx / d * .003; p.vy -= dy / d * .003 * r; }
        p.vx = (p.vx + (Math.random() - .5) * 4e-5) * .985; p.vy = (p.vy + (Math.random() - .5) * 4e-5) * .985; p.x = (p.x + p.vx * sp * L.speed + 1) % 1; p.y = (p.y + p.vy * sp * L.speed + 1) % 1; }
      x.lineCap = 'round';
      for (const p of P) { const px = p.x * w, py = p.y * h, col = 'hsla(' + (H + p.h * L.hueRange) + ',' + Sa + '%,' + clamp(Li + lg, 0, 92) + '%,.9)', rad = L.size * p.s * sz * u;
        if (L.shape === 'line') { x.strokeStyle = col; x.lineWidth = Math.max(1, rad * .6); x.beginPath(); x.moveTo(px, py); x.lineTo(px - p.vx * w * 14, py - p.vy * h * 14); x.stroke(); }
        else if (L.shape === 'ring') { x.strokeStyle = col; x.lineWidth = Math.max(1, rad * .3); x.beginPath(); x.arc(px, py, rad * 1.6, 0, TAU); x.stroke(); } else { x.fillStyle = col; x.beginPath(); x.arc(px, py, rad, 0, TAU); x.fill(); } }
      if (L.link) { x.lineWidth = 1; const D = Math.min(w, h) * .12; for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) { const d = Math.hypot((P[i].x - P[j].x) * w, (P[i].y - P[j].y) * h);
        if (d < D) { x.strokeStyle = 'hsla(' + H + ',80%,70%,' + (1 - d / D) * .5 + ')'; x.beginPath(); x.moveTo(P[i].x * w, P[i].y * h); x.lineTo(P[j].x * w, P[j].y * h); x.stroke(); } } } } }; });

def('weather', 'Ambiente', '🌧️', [S('kind', 'Tipo', [['rain', 'Chuva'], ['snow', 'Neve'], ['stars', 'Estrelas'], ['warp', 'Viagem estelar'], ['fireflies', 'Vaga-lumes'], ['matrix', 'Chuva digital']], 'rain'),
  when(R('count', 'Quantidade', 20, 600, 200), l => l.kind !== 'matrix'), R('speed', 'Velocidade', .2, 4, 1, .1), R('size', 'Tamanho', .5, 6, 2, .5), C('color', 'Cor', '#9fb4ff'),
  when(R('wind', 'Vento', -100, 100, 0, 1, 'Negativo vai para a esquerda'), l => l.kind === 'rain' || l.kind === 'snow' || l.kind === 'stars'), K('audio', 'Acelerar com a música', false)],
  (L, c) => { const k = L.kind, P = Array.from({ length: L.count }, () => ({ x: k === 'warp' ? rnd(-1, 1) : Math.random(), y: k === 'warp' ? rnd(-1, 1) : Math.random(), z: Math.random(), p: Math.random() * TAU, s: .5 + Math.random() })), cols = [];
    return { frame(x, io) { const w = io.w, h = io.h, u = U(w), dt = io.dt / 1000, sp = L.speed * (L.audio ? 1 + io.audio.bass * 3 : 1), wind = L.wind / 100, col = L.color;
      if (k === 'rain') { x.strokeStyle = rgba(col, .55); x.lineWidth = Math.max(1, L.size * .6 * u); x.beginPath();
        for (const p of P) { p.y += (.7 + p.s * .6) * sp * dt; p.x += wind * .35 * dt; if (p.y > 1.05) { p.y = -.05; p.x = Math.random(); } p.x = (p.x + 1) % 1; const px = p.x * w, py = p.y * h, len = (12 + p.s * 16) * u * L.size * .5; x.moveTo(px, py); x.lineTo(px - wind * len * .5, py + len); } x.stroke(); }
      else if (k === 'snow') { x.fillStyle = rgba(col, .85); for (const p of P) { p.y += (.05 + p.s * .09) * sp * dt; p.x += wind * .1 * dt; if (p.y > 1.03) { p.y = -.03; p.x = Math.random(); } p.x = (p.x + 1) % 1;
        x.beginPath(); x.arc(p.x * w + Math.sin(io.t * .001 + p.p) * 18 * u, p.y * h, (1 + p.s * 2.2) * L.size * .7 * u, 0, TAU); x.fill(); } }
      else if (k === 'stars') { for (const p of P) { p.x = (p.x + wind * .01 * dt + 1) % 1; x.fillStyle = rgba(col, .35 + .65 * Math.abs(Math.sin(io.t * .0012 * p.s + p.p))); x.beginPath(); x.arc(p.x * w, p.y * h, (.5 + p.s) * L.size * .6 * u, 0, TAU); x.fill(); } }
      else if (k === 'warp') { for (const p of P) { p.z -= .35 * sp * dt; if (p.z <= .02) { p.x = rnd(-1, 1); p.y = rnd(-1, 1); p.z = 1; } x.fillStyle = rgba(col, 1 - p.z); x.beginPath(); x.arc(w / 2 + p.x / p.z * w * .1, h / 2 + p.y / p.z * w * .1, ((1 - p.z) * 2.5 * L.size + .3) * u, 0, TAU); x.fill(); } }
      else if (k === 'fireflies') { x.globalCompositeOperation = 'lighter'; const r = 22 * L.size * u * .8;
        for (const p of P) { p.p += dt * (.5 + p.s); p.x = (p.x + Math.cos(p.p) * .02 * sp * dt + 1) % 1; p.y = (p.y + Math.sin(p.p * 1.3) * .02 * sp * dt + 1) % 1; const px = p.x * w, py = p.y * h, g = x.createRadialGradient(px, py, 0, px, py, r);
          g.addColorStop(0, rgba(col, .35 + .65 * Math.abs(Math.sin(io.t * .001 * p.s + p.p)))); g.addColorStop(1, rgba(col, 0)); x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2); } }
      else { const fs = 12 * L.size * u + 6, n = Math.max(6, Math.floor(w / fs)); if (cols.length !== n) { cols.length = 0; for (let i = 0; i < n; i++) cols.push({ y: rnd(-30, 0), v: rnd(.6, 1.4) }); }
        x.font = fs + 'px monospace'; x.textAlign = 'left'; x.textBaseline = 'top'; const frame = Math.floor(io.t / 160);
        for (let i = 0; i < n; i++) { const q = cols[i]; q.y += q.v * sp * dt * 14; if ((q.y - 16) * fs > h) { q.y = rnd(-12, 0); q.v = rnd(.6, 1.4); }
          for (let j = 0; j < 16; j++) { const yy = (q.y - j) * fs; if (yy < -fs || yy > h) continue; x.fillStyle = j === 0 ? '#ffffff' : rgba(col, 1 - j / 16); x.fillText(CH[(i * 7 + j * 13 + frame * (j % 3 + 1)) % CH.length], i * fs, yy); } } } } }; });

def('waves', 'Ondas', '🌊', [R('count', 'Quantidade de ondas', 1, 8, 4), R('amp', 'Altura das ondas', 2, 40, 8, 1, 'Em % da tela'), R('speed', 'Velocidade', .2, 4, 1, .1), R('y', 'Posição vertical', 10, 95, 60),
  C('color', 'Cor', '#4aa3ff'), R('spread', 'Variação de cor', 0, 120, 30), K('audio', 'Crescer com a música', true)],
  (L) => { const [H, Sa, Li] = hexHsl(L.color);
    return { frame(x, io) { const w = io.w, h = io.h, lv = L.audio ? io.audio.bass : 0;
      for (let k = 0; k < L.count; k++) { x.fillStyle = 'hsla(' + (H + k * L.spread / Math.max(1, L.count)) + ',' + Sa + '%,' + clamp(Li + k * 3, 0, 90) + '%,' + (.28 + k * .04) + ')'; x.beginPath(); x.moveTo(0, h);
        const base = h * L.y / 100 + k * h * .045, amp = h * L.amp / 100 * (1 + lv * 1.6) * (1 - k * .08);
        for (let i = 0; i <= w; i += 12) x.lineTo(i, base + Math.sin(i * .004 * (1 + k * .15) + io.t * .0007 * L.speed * (1 + k * .3) + k * 2) * amp); x.lineTo(w, h); x.fill(); } } }; });

def('aurora', 'Aurora', '🌌', [C('c1', 'Cor 1', '#3dffb5'), C('c2', 'Cor 2', '#6b8cff'), C('c3', 'Cor 3', '#c06bff'), R('speed', 'Velocidade', .2, 4, 1, .1), R('y', 'Posição vertical', 20, 80, 45), R('height', 'Altura', 10, 70, 35), K('audio', 'Brilhar com a música', true)],
  (L) => ({ frame(x, io) { const w = io.w, h = io.h, a = 1 + (L.audio ? io.audio.level * 1.2 : 0); x.globalCompositeOperation = 'lighter';
    [L.c1, L.c2, L.c3].forEach((col, k) => { const top = h * (L.y - L.height / 2) / 100, bot = h * (L.y + L.height / 2) / 100, g = x.createLinearGradient(0, top, 0, bot);
      g.addColorStop(0, rgba(col, 0)); g.addColorStop(.5, rgba(col, clamp(.5 * a))); g.addColorStop(1, rgba(col, 0)); x.fillStyle = g; x.beginPath(); x.moveTo(0, bot);
      for (let i = 0; i <= w; i += 20) x.lineTo(i, h * (L.y / 100 + k * .06 - .08) + Math.sin(i * .003 + io.t * .0004 * L.speed * (k + 1) + k) * h * L.height / 100 * .35); x.lineTo(w, bot); x.fill(); }); } }));

def('spectrum', 'Espectro de som', '📊', [S('shape', 'Formato', [['bars', 'Barras'], ['mirror', 'Barras espelhadas'], ['ring', 'Anel'], ['line', 'Linha de onda']], 'bars'), C('color', 'Cor', '#8b9cff'), K('rainbow', 'Arco-íris', true),
  when(R('count', 'Quantidade de barras', 16, 96, 48), l => l.shape !== 'line'), R('y', 'Posição vertical', 5, 100, 100, 1, 'Para barras: onde fica a base'), R('size', 'Tamanho (% da tela)', 5, 100, 35), R('gain', 'Sensibilidade', .3, 3, 1, .1)],
  (L) => { const [H, Sa, Li] = hexHsl(L.color);
    return { frame(x, io) { const w = io.w, h = io.h, F = io.audio.freq, n = L.count, col = (i, v) => L.rainbow ? 'hsl(' + ((i / n * 300 + io.t * .02) % 360) + ',85%,' + (55 + v * 20) + '%)' : 'hsl(' + H + ',' + Sa + '%,' + clamp(Li + v * 20, 0, 90) + '%)', val = j => clamp(F[Math.min(63, Math.floor(j / n * 56))] * L.gain);
      if (L.shape === 'bars' || L.shape === 'mirror') { const bw = w / n, base = h * L.y / 100, mx = h * L.size / 100; for (let i = 0; i < n; i++) { const v = val(i); x.fillStyle = col(i, v); x.fillRect(i * bw + bw * .15, L.shape === 'bars' ? base - v * mx : base - v * mx / 2, bw * .7, L.shape === 'bars' ? v * mx : v * mx); } }
      else if (L.shape === 'ring') { const cx = w / 2, cy = h * L.y / 100, r0 = Math.min(w, h) * .18, mx = Math.min(w, h) * L.size / 100; x.lineWidth = Math.max(2, Math.min(w, h) * .006);
        for (let i = 0; i < n; i++) { const a = i / n * TAU, v = val((i < n / 2 ? i : n - 1 - i) * 2), r1 = r0 + v * mx; x.strokeStyle = col(i, v); x.beginPath(); x.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0); x.lineTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); x.stroke(); } }
      else { x.lineWidth = Math.max(2, h * .004); x.strokeStyle = col(0, .5); x.beginPath(); for (let i = 0; i < 128; i++) { const px = i / 127 * w, py = h * L.y / 100 - h * .5 * 0 + io.audio.wave[i] * h * L.size / 200 * L.gain; i ? x.lineTo(px, py) : x.moveTo(px, py); } x.stroke(); } } }; });

def('flash', 'Flash na batida', '⚡', [C('color', 'Cor do flash', '#ffffff'), R('intensity', 'Intensidade', 5, 100, 40), R('threshold', 'Quão forte a batida precisa ser', .1, .9, .35, .05, 'Maior = só os graves mais fortes')],
  (L) => ({ frame(x, io) { const a = clamp((io.audio.bass - L.threshold) / (1 - L.threshold)) * L.intensity / 100; if (a > .01) { x.fillStyle = rgba(L.color, a); x.fillRect(0, 0, io.w, io.h); } } }));

def('text', 'Texto', '✍️', [S('kind', 'O que mostrar', [['text', 'Meu texto'], ['clock', 'Hora'], ['date', 'Data'], ['both', 'Hora e data']], 'text'), when(T('text', 'Texto', 'Olá!', 'Use Enter para pular linha'), l => l.kind === 'text'),
  when(K('h24', 'Relógio de 24 horas', true), l => l.kind === 'clock' || l.kind === 'both'), when(K('seconds', 'Mostrar segundos', false), l => l.kind === 'clock' || l.kind === 'both'),
  S('font', 'Fonte', FONTS, 'Outfit'), R('size', 'Tamanho', 2, 50, 14, 1, 'Em % da altura da tela'), C('color', 'Cor', '#ffffff'), K('bold', 'Negrito', true), S('align', 'Alinhamento', [['center', 'Centro'], ['left', 'Esquerda'], ['right', 'Direita']], 'center'),
  R('x', 'Posição horizontal', 0, 100, 50), R('y', 'Posição vertical', 0, 100, 50), R('glow', 'Brilho (neon)', 0, 100, 0), R('pulse', 'Pulsar com a música', 0, 100, 0)],
  (L) => ({ frame(x, io) { const w = io.w, h = io.h, d = new Date(), hora = () => d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: L.seconds ? '2-digit' : undefined, hour12: !L.h24 }),
      data = () => d.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }), lines = L.kind === 'text' ? String(L.text).split('\n') : L.kind === 'clock' ? [hora()] : L.kind === 'date' ? [data()] : [hora(), data()];
    const px = h * L.size / 100 * (1 + io.audio.bass * L.pulse / 100 * .3); x.textAlign = L.align; x.textBaseline = 'middle'; x.fillStyle = L.color; if (L.glow) { x.shadowColor = L.color; x.shadowBlur = L.glow * .5 * U(w); }
    let y = h * L.y / 100 - (lines.length - 1) * px * .55; lines.forEach((s, i) => { const k = L.kind === 'both' && i === 1 ? .38 : 1; x.font = (L.bold ? '700 ' : '400 ') + px * k + 'px "' + L.font + '", sans-serif'; x.fillText(s, w * L.x / 100, y); y += px * (k < 1 ? .9 : 1.15); }); } }));

def('shape', 'Forma', '⚪', [S('kind', 'Forma', [['circle', 'Círculo'], ['ring', 'Anel'], ['square', 'Quadrado'], ['triangle', 'Triângulo'], ['star', 'Estrela'], ['heart', 'Coração']], 'circle'), C('color', 'Cor', '#8b9cff'),
  when(K('outline', 'Só o contorno', false), l => l.kind !== 'ring'), R('thickness', 'Espessura do contorno', 1, 20, 4), R('size', 'Tamanho', 2, 90, 20, 1, 'Em % da tela'), R('x', 'Posição horizontal', 0, 100, 50), R('y', 'Posição vertical', 0, 100, 50),
  R('spin', 'Girar', -100, 100, 0), R('pulse', 'Pulsar com a música', 0, 100, 40), S('follow', 'Em relação ao cursor', [['none', 'Ficar parada'], ['follow', 'Seguir o cursor'], ['away', 'Fugir do cursor']], 'none')],
  (L) => { let px = L.x / 100, py = L.y / 100;
    return { frame(x, io) { const w = io.w, h = io.h, m = io.mouse, k = 1 - Math.exp(-io.dt / 220), bx = L.x / 100, by = L.y / 100;
      if (L.follow === 'follow') { px += (m.nx - px) * k; py += (m.ny - py) * k; } else if (L.follow === 'away') { px += (bx + (bx - m.nx) * .35 - px) * k; py += (by + (by - m.ny) * .35 - py) * k; } else { px = bx; py = by; }
      const s = Math.min(w, h) * L.size / 100 * (1 + io.audio.bass * L.pulse / 100 * .5) / 2; x.translate(px * w, py * h); x.rotate(io.t / 1000 * L.spin * 1.8 * Math.PI / 180); x.beginPath();
      if (L.kind === 'circle' || L.kind === 'ring') x.arc(0, 0, s, 0, TAU); else if (L.kind === 'square') x.rect(-s, -s, s * 2, s * 2);
      else if (L.kind === 'triangle') { x.moveTo(0, -s); x.lineTo(s * .9, s * .7); x.lineTo(-s * .9, s * .7); x.closePath(); }
      else if (L.kind === 'star') { for (let i = 0; i < 10; i++) { const r = i % 2 ? s * .45 : s, a = -Math.PI / 2 + i * Math.PI / 5; x.lineTo(Math.cos(a) * r, Math.sin(a) * r); } x.closePath(); }
      else { x.moveTo(0, s * .9); x.bezierCurveTo(-s * 1.4, s * .1, -s * .8, -s * .9, 0, -s * .3); x.bezierCurveTo(s * .8, -s * .9, s * 1.4, s * .1, 0, s * .9); x.closePath(); }
      if (L.outline || L.kind === 'ring') { x.lineWidth = L.thickness * U(w); x.strokeStyle = L.color; x.stroke(); } else { x.fillStyle = L.color; x.fill(); } } }; });

def('cursorfx', 'Efeito no cursor', '🖱️', [S('kind', 'Efeito', [['glow', 'Brilho'], ['trail', 'Rastro de luz'], ['ripples', 'Ondas'], ['sparks', 'Faíscas ao clicar']], 'glow'), C('color', 'Cor', '#8b9cff'), K('rainbow', 'Arco-íris', false), R('size', 'Tamanho', 4, 80, 30)],
  (L) => { const P = [], W = []; let last = 0;
    return { frame(x, io) { const m = io.mouse, u = U(io.w), col = (o, a) => L.rainbow ? 'hsla(' + ((io.t * .05 + o) % 360) + ',90%,62%,' + a + ')' : rgba(L.color, a);
      if (L.kind === 'glow') { const r = L.size * 3 * u * (1 + (m.down ? .6 : 0) + io.audio.level * .8), g = x.createRadialGradient(m.x, m.y, 0, m.x, m.y, r); g.addColorStop(0, col(0, .9)); g.addColorStop(1, col(0, 0)); x.fillStyle = g; x.beginPath(); x.arc(m.x, m.y, r, 0, TAU); x.fill(); }
      else if (L.kind === 'trail') { const s = m.down ? 3 : 1; for (let i = 0; i < (m.down ? 5 : 2); i++) P.push({ x: m.x, y: m.y, vx: rnd(-1, 1) * s, vy: rnd(-1, 1) * s, l: 1, o: i * 20 }); if (P.length > 700) P.splice(0, P.length - 700);
        for (let i = P.length - 1; i >= 0; i--) { const p = P[i]; p.x += p.vx; p.y += p.vy; p.l -= .02; if (p.l <= 0) { P.splice(i, 1); continue; } x.fillStyle = col(p.o, p.l * .8); x.beginPath(); x.arc(p.x, p.y, (1 + p.l * L.size * .25) * u, 0, TAU); x.fill(); } }
      else if (L.kind === 'ripples') { if (io.t - last > (m.down ? 140 : 500)) { last = io.t; W.push({ x: m.x, y: m.y, r: 0, big: m.down }); } if (m.pressed) W.push({ x: m.x, y: m.y, r: 0, big: true });
        for (let i = W.length - 1; i >= 0; i--) { const q = W[i]; q.r += (q.big ? 6 : 3.5) * u; const a = 1 - q.r / (Math.min(io.w, io.h) * (q.big ? .7 : .4)); if (a <= 0) { W.splice(i, 1); continue; } x.strokeStyle = col(i * 30, a); x.lineWidth = (2 + a * 3) * u * L.size / 30; x.beginPath(); x.arc(q.x, q.y, q.r, 0, TAU); x.stroke(); } }
      else { if (m.pressed || (m.down && Math.random() < .5)) for (let i = 0; i < 14; i++) { const a = rnd(0, TAU), v = rnd(2, 9); P.push({ x: m.x, y: m.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 1, o: i * 25 }); }
        x.lineWidth = Math.max(1, L.size / 12 * u); for (let i = P.length - 1; i >= 0; i--) { const p = P[i]; p.vy += .15; p.x += p.vx; p.y += p.vy; p.l -= .025; if (p.l <= 0) { P.splice(i, 1); continue; } x.strokeStyle = col(p.o, p.l); x.beginPath(); x.moveTo(p.x, p.y); x.lineTo(p.x - p.vx * 2, p.y - p.vy * 2); x.stroke(); } } } }; });

def('filter', 'Filtro de tela', '🎞️', [S('kind', 'Filtro', [['vignette', 'Vinheta (bordas escuras)'], ['scanlines', 'TV antiga (linhas)'], ['grain', 'Granulado de filme'], ['tint', 'Tom de cor']], 'vignette'), R('strength', 'Intensidade', 0, 100, 50),
  when(C('color', 'Cor', '#000000'), l => l.kind === 'vignette' || l.kind === 'tint'), when(R('spacing', 'Espaço entre as linhas', 2, 12, 4), l => l.kind === 'scanlines')],
  (L) => { let tile = null, n = 0;
    return { frame(x, io) { const w = io.w, h = io.h, a = L.strength / 100;
      if (L.kind === 'vignette') { const g = x.createRadialGradient(w / 2, h / 2, Math.min(w, h) * .3, w / 2, h / 2, Math.hypot(w, h) / 2); g.addColorStop(0, rgba(L.color, 0)); g.addColorStop(1, rgba(L.color, a * .95)); x.fillStyle = g; x.fillRect(0, 0, w, h); }
      else if (L.kind === 'scanlines') { x.fillStyle = rgba('#000000', a * .4); const s = Math.max(2, L.spacing * U(w)); for (let y = 0; y < h; y += s * 2) x.fillRect(0, y, w, s); }
      else if (L.kind === 'grain') { if (!tile) { tile = document.createElement('canvas'); tile.width = tile.height = 128; }
        if (n++ % 3 === 0) { const t = tile.getContext('2d'), id = t.createImageData(128, 128); for (let i = 0; i < id.data.length; i += 4) { const v = Math.random() * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; } t.putImageData(id, 0, 0); }
        x.globalAlpha *= a * .35; x.fillStyle = x.createPattern(tile, 'repeat'); x.translate(rnd(0, 128), rnd(0, 128)); x.fillRect(-128, -128, w + 256, h + 256); }
      else { x.fillStyle = rgba(L.color, a * .6); x.fillRect(0, 0, w, h); } } }; });

const defaultsOf = type => { const o = {}; LT[type].props.concat(type === 'bg' ? [] : COMMON).forEach(p => { o[p.k] = p.d; }); return o; };
const mk = (type, over = {}) => ({ type, ...defaultsOf(type), ...over });

// ---- palette (botões de "adicionar") ----
const PALETTE = [
  ['Imagens e vídeos', [['media', 'Imagem, GIF ou vídeo', '🖼️', 'Coloque uma imagem, GIF animado ou vídeo seu na tela', {}]]],
  ['Clima e ambiente', [['weather', 'Chuva', '🌧️', 'Gotas caindo', { kind: 'rain', color: '#9fb4ff', count: 220 }], ['weather', 'Neve', '❄️', 'Flocos caindo devagar', { kind: 'snow', color: '#ffffff', count: 160 }],
    ['weather', 'Estrelas', '✨', 'Estrelas que piscam', { kind: 'stars', color: '#ffffff', count: 200, size: 2 }], ['weather', 'Viagem estelar', '🚀', 'Estrelas vindo na sua direção', { kind: 'warp', color: '#cfe0ff', count: 260, size: 2 }],
    ['weather', 'Vaga-lumes', '🌟', 'Luzinhas flutuando', { kind: 'fireflies', color: '#d8ff8a', count: 45, size: 2 }], ['weather', 'Chuva digital', '💻', 'Letras caindo, estilo Matrix', { kind: 'matrix', color: '#33ff88', size: 2 }],
    ['waves', 'Ondas', '🌊', 'Ondas do mar que sobem com a música', {}], ['aurora', 'Aurora', '🌌', 'Luzes coloridas no céu', {}], ['particles', 'Partículas', '🫧', 'Pontinhos que reagem ao cursor e à música', {}]]],
  ['Música', [['spectrum', 'Barras de som', '📊', 'Barrinhas que dançam com a música', {}], ['spectrum', 'Anel de som', '🔊', 'Anel que pulsa com a música', { shape: 'ring', y: 50, size: 25 }],
    ['spectrum', 'Onda de som', '〰️', 'Linha que desenha o som', { shape: 'line', y: 50, size: 30 }], ['flash', 'Flash na batida', '⚡', 'A tela pisca nos graves', {}]]],
  ['Cursor (mouse)', [['cursorfx', 'Brilho no cursor', '🖱️', 'Uma luz segue o mouse', {}], ['cursorfx', 'Rastro de luz', '💫', 'O mouse deixa um rastro', { kind: 'trail' }],
    ['cursorfx', 'Ondas ao clicar', '💧', 'Ondas saem do mouse', { kind: 'ripples' }], ['cursorfx', 'Faíscas ao clicar', '🎆', 'Clique e saem faíscas', { kind: 'sparks' }]]],
  ['Texto', [['text', 'Texto', '✍️', 'Escreva o que quiser, escolha a fonte', {}], ['text', 'Relógio', '🕒', 'Hora atual', { kind: 'clock', size: 18 }], ['text', 'Data', '📅', 'Dia da semana e data', { kind: 'date', size: 6, y: 62 }]]],
  ['Formas', [['shape', 'Círculo', '⚪', 'Um círculo que pode pulsar e seguir o mouse', {}], ['shape', 'Anel', '⭕', 'Um anel', { kind: 'ring' }], ['shape', 'Quadrado', '⬜', 'Um quadrado', { kind: 'square' }],
    ['shape', 'Estrela', '⭐', 'Uma estrela', { kind: 'star', color: '#ffd66b' }], ['shape', 'Coração', '❤️', 'Um coração', { kind: 'heart', color: '#ff6f9f' }]]],
  ['Filtros de tela', [['filter', 'Vinheta', '🎞️', 'Escurece as bordas', {}], ['filter', 'TV antiga', '📺', 'Linhas de TV de tubo', { kind: 'scanlines' }], ['filter', 'Granulado', '🌫️', 'Textura de filme', { kind: 'grain' }], ['filter', 'Tom de cor', '🎨', 'Pinta tudo com uma cor suave', { kind: 'tint', color: '#4a2bff', strength: 30 }]]]];

const TEMPLATES = [
  ['Noite estrelada', () => ({ bg: mk('bg', { c1: '#05070f', c2: '#14204a' }), layers: [mk('weather', { name: 'Estrelas', kind: 'stars', color: '#ffffff', count: 220, size: 2 }), mk('aurora', { name: 'Aurora' }), mk('shape', { name: 'Lua', kind: 'circle', color: '#fff7d6', size: 9, x: 80, y: 22, pulse: 0 }), mk('filter', { name: 'Vinheta', strength: 55 })] })],
  ['Cyberpunk na chuva', () => ({ bg: mk('bg', { c1: '#0a0612', c2: '#2a0b3d' }), layers: [mk('weather', { name: 'Chuva', kind: 'rain', color: '#ff4fd8', count: 260, wind: 20 }), mk('text', { name: 'Relógio', kind: 'clock', font: 'Bahnschrift', color: '#ff4fd8', glow: 70, size: 16, y: 45 }), mk('filter', { name: 'TV antiga', kind: 'scanlines', strength: 40 }), mk('filter', { name: 'Granulado', kind: 'grain', strength: 25 })] })],
  ['Lo-fi aconchegante', () => ({ bg: mk('bg', { c1: '#1b1020', c2: '#3b1f2b' }), layers: [mk('weather', { name: 'Vaga-lumes', kind: 'fireflies', color: '#ffd27a', count: 40, size: 2 }), mk('text', { name: 'Hora e data', kind: 'both', color: '#ffe9c7', size: 12, y: 48 }), mk('filter', { name: 'Vinheta', strength: 60 })] })],
  ['Equalizador neon', () => ({ bg: mk('bg', { mode: 'solid', c1: '#05060d' }), layers: [mk('spectrum', { name: 'Anel', shape: 'ring', y: 50, size: 25 }), mk('spectrum', { name: 'Barras', size: 22 }), mk('flash', { name: 'Flash', intensity: 22 }), mk('cursorfx', { name: 'Brilho no cursor' })] })],
  ['Chuva digital', () => ({ bg: mk('bg', { mode: 'solid', c1: '#000000' }), layers: [mk('weather', { name: 'Matrix', kind: 'matrix', color: '#33ff88', size: 2 }), mk('filter', { name: 'Vinheta', strength: 60 })] })],
  ['Oceano profundo', () => ({ bg: mk('bg', { c1: '#07203a', c2: '#0b4a6e' }), layers: [mk('waves', { name: 'Ondas', count: 5 }), mk('particles', { name: 'Bolhas', shape: 'ring', count: 40, size: 3, speed: .4, color: '#bfe8ff', hueRange: 20, audio: 'none' })] })],
  ['Viagem estelar', () => ({ bg: mk('bg', { mode: 'solid', c1: '#02030a' }), layers: [mk('weather', { name: 'Estrelas', kind: 'warp', color: '#cfe0ff', count: 260, size: 2 }), mk('cursorfx', { name: 'Rastro', kind: 'trail' })] })]];

const fromCustom = cfg => { const D = { bg1: '#0b0d16', bg2: '#1a1040', trails: 25, shape: 'dot', count: 140, size: 3, speed: 1, hue: 210, hueRange: 60, light: 62, link: false, cursor: 'attract', cursorForce: 1, click: true, audio: 'both', audioGain: 1, spectrum: 'none', ...cfg }, hex = hslHex(D.hue, 85, D.light);
  const layers = [mk('particles', { name: 'Partículas', shape: D.shape, count: D.count, size: D.size, speed: D.speed, color: hex, hueRange: D.hueRange, link: D.link, cursor: D.cursor, cursorForce: D.cursorForce, click: D.click, audio: D.audio, audioGain: D.audioGain })];
  if (D.spectrum === 'bars' || D.spectrum === 'ring') layers.push(mk('spectrum', { name: 'Espectro de som', shape: D.spectrum, color: hex, y: D.spectrum === 'ring' ? 50 : 100, size: D.spectrum === 'ring' ? 25 : 35 }));
  return { bg: mk('bg', { c1: D.bg1, c2: D.bg2, trails: D.trails }), layers }; };

function makeStudio(cfg, c) {
  const { io, tick } = makeIO(c), used = [];
  const use = url => { const m = loadMedia(url); if (m) { m.refs = (m.refs || 0) + 1; used.push(m); if (m.video) m.video.play().catch(() => {}); } return m; };
  const list = [mk('bg', (cfg && cfg.bg) || {}), ...((cfg && cfg.layers) || [])].filter(l => l && LT[l.type] && l.visible !== false).map(l => ({ ...defaultsOf(l.type), ...l })), inst = list.map(l => LT[l.type].make(l, c, use));
  return { frame(t) { tick(t); const x = c.getContext('2d');
      list.forEach((l, i) => { x.save(); if (l.type !== 'bg') { x.globalAlpha = clamp(l.opacity / 100); x.globalCompositeOperation = l.blend; }
        try { inst[i].frame(x, io); } catch (e) { if (window.__STUDIO_DEBUG) throw e; } x.restore(); }); },
    pause: v => used.forEach(m => m.video && (v ? m.video.pause() : m.video.play().catch(() => {}))),
    stop: () => used.forEach(m => { if (--m.refs <= 0 && m.video) m.video.pause(); }) };
}
window.STUDIO = { LT, COMMON, PALETTE, TEMPLATES, FONTS, make: mk, defaults: defaultsOf, fromCustom, hexHsl, hslHex };
window.makeStudio = makeStudio; window.runStudio = (cfg, canvas, fps = 30) => runLoop(makeStudio(cfg, canvas), canvas, fps);
})();
