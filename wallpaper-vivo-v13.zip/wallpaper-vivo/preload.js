const { contextBridge, ipcRenderer: ipc, webUtils } = require('electron');
contextBridge.exposeInMainWorld('api', {
  state: () => ipc.invoke('state'), apply: i => ipc.invoke('apply', i), stop: () => ipc.invoke('stop'),
  plist: i => ipc.invoke('plist', i), next: () => ipc.invoke('next'),
  onState: cb => ipc.on('state', (_, s) => cb(s)),
  onCursor: cb => ipc.on('cursor', (_, c) => cb(c)),
  sceneInit: () => ipc.invoke('scene-init'), onScene: cb => ipc.on('scene', (_, a) => cb(a)), saveCustom: i => ipc.invoke('saveCustom', i),
  storeSearch: o => ipc.invoke('store-search', o), storeDownload: i => ipc.invoke('store-download', i), storeUrl: u => ipc.invoke('store-url', u),
  catalogAdd: u => ipc.invoke('catalog-add', u), openUrl: u => ipc.invoke('open-url', u), onDl: cb => ipc.on('dl', (_, d) => cb(d)),
  pathFor: f => { try { return webUtils.getPathForFile(f); } catch { return ''; } }, addFiles: p => ipc.invoke('add-files', p), dropBlob: o => ipc.invoke('drop-blob', o),
  watchPick: () => ipc.invoke('watch-pick'), watchOpen: () => ipc.invoke('watch-open'), onToast: cb => ipc.on('toast', (_, m) => cb(m)),
  version: () => ipc.invoke('version'), updateCheck: () => ipc.invoke('update-check'), updateInstall: () => ipc.invoke('update-install'), onUpdate: cb => ipc.on('update', (_, s) => cb(s)),
  pickMedia: () => ipc.invoke('pick-media'),
  displays: () => ipc.invoke('displays'), identify: () => ipc.invoke('identify-displays'), onDisplays: cb => ipc.on('displays', () => cb()),
  pick: () => ipc.invoke('pick'), remove: s => ipc.invoke('remove', s), opt: (k, v) => ipc.invoke('opt', k, v),
  onPause: cb => ipc.on('pause', (_, v) => cb(v))
});
