// Encaixa uma janela do Electron atrás dos ícones da área de trabalho (Windows 10/11).
const koffi = require('koffi');
const user32 = koffi.load('user32.dll');

const FindWindowW = user32.func('intptr_t __stdcall FindWindowW(str16 cls, str16 name)');
const FindWindowExW = user32.func('intptr_t __stdcall FindWindowExW(intptr_t parent, intptr_t after, str16 cls, str16 name)');
const SendMessageTimeoutW = user32.func('intptr_t __stdcall SendMessageTimeoutW(intptr_t h, uint32 msg, uintptr_t w, intptr_t l, uint32 flags, uint32 timeout, _Out_ uintptr_t *res)');
const SetParent = user32.func('intptr_t __stdcall SetParent(intptr_t child, intptr_t parent)');
const SetWindowPos = user32.func('bool __stdcall SetWindowPos(intptr_t h, intptr_t after, int x, int y, int cx, int cy, uint32 flags)');
const EnumProc = koffi.proto('bool __stdcall EnumWindowsProc(intptr_t hwnd, intptr_t lp)');
const EnumWindows = user32.func('bool __stdcall EnumWindows(EnumWindowsProc *cb, intptr_t lp)');

function findWorkerW() {
  const progman = FindWindowW('Progman', null);
  if (!progman) throw new Error('Progman não encontrado');
  SendMessageTimeoutW(progman, 0x052C, 0xD, 1, 0, 1000, [0]); // cria o WorkerW atrás dos ícones
  let worker = 0;
  const cb = koffi.register((hwnd) => {
    if (FindWindowExW(hwnd, 0, 'SHELLDLL_DefView', null)) worker = FindWindowExW(0, hwnd, 'WorkerW', null);
    return true;
  }, koffi.pointer(EnumProc));
  EnumWindows(cb, 0);
  koffi.unregister(cb);
  if (!worker) worker = FindWindowExW(progman, 0, 'WorkerW', null); // Windows 11 24H2
  if (!worker) worker = progman;
  return worker;
}

function attach(win, r) {
  const hwnd = Number(win.getNativeWindowHandle().readBigUInt64LE(0));
  SetParent(hwnd, findWorkerW());
  SetWindowPos(hwnd, 0, r.x, r.y, r.width, r.height, 0x0054); // sem ativar, sem mudar ordem, mostrar
}
// Janela em primeiro plano (para saber se algo está em tela cheia agora)
koffi.struct('RECT', { left: 'int32', top: 'int32', right: 'int32', bottom: 'int32' });
const GetForegroundWindow = user32.func('intptr_t __stdcall GetForegroundWindow()');
const IsIconic = user32.func('bool __stdcall IsIconic(intptr_t h)');
const IsWindowVisible = user32.func('bool __stdcall IsWindowVisible(intptr_t h)');
const GetWindowRect = user32.func('bool __stdcall GetWindowRect(intptr_t h, _Out_ RECT *r)');
const GetClassNameW = user32.func('int __stdcall GetClassNameW(intptr_t h, _Out_ uint8_t *buf, int n)');
const GetWindowThreadProcessId = user32.func('uint32 __stdcall GetWindowThreadProcessId(intptr_t h, _Out_ uint32 *pid)');
const SKIP = new Set(['Progman', 'WorkerW', 'Shell_TrayWnd', 'Shell_SecondaryTrayWnd']);
function fgRect() {
  const h = GetForegroundWindow();
  if (!h || IsIconic(h) || !IsWindowVisible(h)) return null; // minimizada = não conta
  const pid = [0]; GetWindowThreadProcessId(h, pid);
  if (pid[0] === process.pid) return null;
  const buf = Buffer.alloc(512), n = GetClassNameW(h, buf, 256);
  if (SKIP.has(buf.toString('utf16le', 0, n * 2))) return null; // área de trabalho / barra de tarefas
  const r = {}; return GetWindowRect(h, r) ? r : null;
}
// Todas as janelas grandes visíveis (de cima para baixo na ordem de empilhamento), para saber se algo cobre algum monitor,
// mesmo que a janela não esteja em foco (ex.: jogo no monitor 2 enquanto você usa o monitor 1).
const GetTopWindow = user32.func('intptr_t __stdcall GetTopWindow(intptr_t h)');
const GetWindow = user32.func('intptr_t __stdcall GetWindow(intptr_t h, uint32 cmd)');
const DwmGetWindowAttribute = koffi.load('dwmapi.dll').func('int32 __stdcall DwmGetWindowAttribute(intptr_t h, uint32 attr, _Out_ int32 *val, uint32 size)');
const SKIP2 = new Set([...SKIP, 'XamlExplorerHostIslandWindow', 'MultitaskingViewFrame', 'ForegroundStaging', 'TaskSwitcherWnd']);
function coverRects(minW = 600, minH = 400) {
  const out = [];
  for (let h = GetTopWindow(0), n = 0; h && n < 4000; h = GetWindow(h, 2), n++) {
    if (!IsWindowVisible(h) || IsIconic(h)) continue;                                  // escondida ou minimizada
    const r = {}; if (!GetWindowRect(h, r) || r.right - r.left < minW || r.bottom - r.top < minH) continue;
    const pid = [0]; GetWindowThreadProcessId(h, pid); if (pid[0] === process.pid) continue;   // nossas próprias janelas
    const buf = Buffer.alloc(512), len = GetClassNameW(h, buf, 256); if (SKIP2.has(buf.toString('utf16le', 0, len * 2))) continue;   // área de trabalho, barra de tarefas, Alt+Tab
    const cl = [0]; DwmGetWindowAttribute(h, 14, cl, 4); if (cl[0]) continue;          // "escondida" em outra área de trabalho virtual
    out.push({ left: r.left, top: r.top, right: r.right, bottom: r.bottom });
  }
  return out;
}
const GetAsyncKeyState = user32.func('int16 __stdcall GetAsyncKeyState(int vk)');
const mouseDown = () => (GetAsyncKeyState(0x01) & 0x8000) !== 0; // botão esquerdo
module.exports = { attach, fgRect, coverRects, mouseDown };
