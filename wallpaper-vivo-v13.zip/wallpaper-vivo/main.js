const { app, BrowserWindow, Tray, Menu, ipcMain, dialog, screen, nativeImage, powerMonitor, session, desktopCapturer, nativeTheme, shell } = require('electron');
const path = require('path'), fs = require('fs'), { pathToFileURL } = require('url');
let attach, fgRect, coverRects, mouseDown, loadErr;
async function loadWallpaperLib() {
  try { ({ attach, fgRect, coverRects, mouseDown } = require('./wallpaper-attach')); }
  catch (e) { loadErr = e.stack || e.message; }
}

if (!app.requestSingleInstanceLock()) app.quit();
const cfgFile = () => path.join(app.getPath('userData'), 'settings.json');
let S = { current: null, fps: 30, muted: true, autostart: false, pauseOnBattery: true, pauseOnFullscreen: true, pauseScope: 'all', monitors: 'primary', monitorIds: [], playlist: [], playEnabled: false, playMinutes: 10, playRandom: false, fade: 1.2, theme: 'auto', keys: { pexels: '', pixabay: '' }, catalogs: [], autoUpdate: true, watchOn: false, watchDir: '', watchIgnore: [], library: [] };
try { S = { ...S, ...JSON.parse(fs.readFileSync(cfgFile(), 'utf8')) }; } catch {}
const save = () => fs.writeFileSync(cfgFile(), JSON.stringify(S, null, 2));
const store = require('./store'), crypto = require('crypto'), updater = require('./updater');
// ---------- Iniciar com o Windows: grava a entrada com aspas corretas e aponta para o APP (não para o "electron" puro) ----------
const { execFile } = require('child_process');
const RUN_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run', APPROVED_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run', RUN_NAME = 'Wallpaper Vivo';
const reg = args => new Promise(r => execFile('reg', args, { windowsHide: true }, (err, out) => r(err ? null : String(out || ''))));
const startupCmd = () => app.isPackaged ? '"' + process.execPath + '" --hidden' : '"' + process.execPath + '" "' + app.getAppPath() + '" --hidden';
async function applyAutostart(on) {
  if (process.platform !== 'win32') { try { app.setLoginItemSettings({ openAtLogin: !!on }); } catch {} return; }
  try { app.setLoginItemSettings({ openAtLogin: false }); } catch {}                  // limpa entradas antigas feitas pelo próprio Electron
  const exe = process.execPath.toLowerCase(), appDir = app.getAppPath().toLowerCase(), out = await reg(['query', RUN_KEY]);
  for (const line of String(out || '').split(/\r?\n/)) {
    const m = /^\s+(.+?)\s+REG_(?:EXPAND_)?SZ\s+(.*)$/.exec(line); if (!m || m[1] === RUN_NAME) continue;
    const d = m[2].toLowerCase(), bare = d.replace(/"/g, '').trim() === exe;           // entrada antiga: só o electron.exe, sem o app
    if (bare || d.includes(appDir) || (app.isPackaged && d.includes(exe))) await reg(['delete', RUN_KEY, '/v', m[1], '/f']);
  }
  if (on) { await reg(['add', RUN_KEY, '/v', RUN_NAME, '/t', 'REG_SZ', '/d', startupCmd(), '/f']); await reg(['delete', APPROVED_KEY, '/v', RUN_NAME, '/f']); }
  else await reg(['delete', RUN_KEY, '/v', RUN_NAME, '/f']);
}
// ---------- Monitores ----------
const sortedDisplays = () => screen.getAllDisplays().slice().sort((a, b) => a.bounds.x - b.bounds.x || a.bounds.y - b.bounds.y);
function targetDisplays() {
  const all = screen.getAllDisplays(), ids = (S.monitorIds || []).map(Number), t = all.filter(d => ids.includes(Number(d.id)));
  if (ids.length) return t.length ? t : [screen.getPrimaryDisplay()];   // escolha feita pelo usuário; se o monitor sumiu, volta ao principal
  return S.monitors === 'all' ? all : [screen.getPrimaryDisplay()];       // configuração antiga (versões anteriores)
}
// Windows 11 (build 22621+): fundo translúcido "Mica", inclusive na barra de título
const MICA = process.platform === 'win32' && Number(require('os').release().split('.')[2]) >= 22621;
const overlay = () => { const d = nativeTheme.shouldUseDarkColors;
  return { color: MICA ? '#00000000' : (d ? '#0d0f17' : '#f3f4fa'), symbolColor: d ? '#eceef6' : '#181a26', height: 46 }; };
const AUDIO_FX = ['bars', 'ring', 'soundwave'];
const CURSOR_FX = ['trail', 'magnet', 'ripples', 'dots'];
const preload = path.join(__dirname, 'preload.js');
const icon = nativeImage.createFromPath(path.join(__dirname, 'icon.png'));
let panel, walls = [], tray, manual = false, battery = false, errShown = false;
const wallPaused = w => manual || battery || !!w._full;
let errShownReset = () => { errShown = false; };

function stopWalls() { walls.forEach(w => { if (!w.isDestroyed()) w.destroy(); }); walls = []; }
function startWalls() {
  stopWalls(); errShownReset();
  if (!S.current) return;
  const all = screen.getAllDisplays(), rect = d => screen.dipToScreenRect(null, d.bounds);
  const ox = Math.min(...all.map(d => rect(d).x)), oy = Math.min(...all.map(d => rect(d).y));
  for (const d of targetDisplays()) {
    const r = rect(d);
    const w = new BrowserWindow({ ...d.bounds, frame: false, show: false, skipTaskbar: true, focusable: false,
      webPreferences: { preload, backgroundThrottling: false } });
    w._r = r; w._b = d.bounds;
    w.loadFile(path.join(__dirname, 'wallpaper.html'));
    w.webContents.on('did-finish-load', () => {
      if (w.isDestroyed()) return;
      w.webContents.send('pause', wallPaused(w));
      if (needsAudio(S.current)) startAudio(w);
    });
    w.once('ready-to-show', () => {
      w.show();
      if (attach) { try { attach(w, { x: r.x - ox, y: r.y - oy, width: r.width, height: r.height }); } catch (e) { console.error(e); } }
      else if (!errShown) { errShown = true; dialog.showErrorBox('Módulo não carregou', loadErr || 'Erro desconhecido'); stopWalls(); }
    });
    walls.push(w);
  }
}
let plTimer;
function schedulePlaylist() {
  clearInterval(plTimer);
  if (S.playEnabled && S.playlist.length > 1) plTimer = setInterval(nextWallpaper, Math.max(1, S.playMinutes) * 60000);
}
function nextWallpaper() {
  const L = S.playlist; if (L.length < 2) return;
  const i = L.findIndex(x => S.current && x.src === S.current.src);
  let n = (i + 1) % L.length;
  if (S.playRandom) do n = Math.floor(Math.random() * L.length); while (n === i);
  S.current = L[n]; save(); switchWalls();
  if (panel && !panel.isDestroyed()) panel.webContents.send('state', S);
}
// O wallpaper fica atrás dos ícones e não recebe o mouse: lemos o cursor do sistema e enviamos a ele.
function pollCursor() {
  const it = S.current;
  if (!it || !(it.type === 'custom' || it.type === 'code' || it.type === 'studio' || (it.type === 'effect' && CURSOR_FX.includes(it.src)))) return;
  const p = screen.getCursorScreenPoint(); let down = false;
  try { down = !!mouseDown && mouseDown(); } catch {}
  for (const w of walls) {
    if (w.isDestroyed() || wallPaused(w)) continue;
    const b = w._b;
    w.webContents.send('cursor', { x: (p.x - b.x) / b.width, y: (p.y - b.y) / b.height, down,
      in: p.x >= b.x && p.x < b.x + b.width && p.y >= b.y && p.y < b.y + b.height });
  }
}
const needsAudio = it => !!it && (it.type === 'effect' ? AUDIO_FX.includes(it.src) : it.type === 'studio' ? true : it.type === 'code' ? /audio/.test(it.code || '') : it.type === 'custom' && ((it.config || {}).audio !== 'none' || (it.config || {}).spectrum !== 'none'));
const startAudio = w => w.webContents.executeJavaScript('window.startAudio&&startAudio()', true).catch(() => {});
const sceneArgs = () => ({ type: S.current.type, src: S.current.src, config: S.current.config, code: S.current.code, fps: S.fps, muted: S.muted, fade: S.fade });
// Troca o wallpaper com transição suave (sem recriar as janelas)
function switchWalls() {
  if (!S.current) return stopWalls();
  if (!walls.length || walls.some(w => w.isDestroyed())) return startWalls();
  walls.forEach(w => { w.webContents.send('scene', sceneArgs()); if (needsAudio(S.current)) startAudio(w); });
}
function sendPause() { walls.forEach(w => !w.isDestroyed() && w.webContents.send('pause', wallPaused(w))); buildTray(); }
function pollFull() {
  let rects = null;
  if (S.pauseOnFullscreen && coverRects) { try { rects = coverRects(); } catch {} }
  const covers = (f, r) => f.left <= r.x + 2 && f.top <= r.y + 2 && f.right >= r.x + r.width - 2 && f.bottom >= r.y + r.height - 2;
  const hit = r => !!rects && rects.some(f => covers(f, r));
  // "all": qualquer monitor coberto (mesmo um sem wallpaper) pausa todos. "monitor": só o monitor coberto pausa.
  const any = !!rects && screen.getAllDisplays().some(d => hit(screen.dipToScreenRect(null, d.bounds)));
  let changed = false;
  for (const w of walls) {
    if (w.isDestroyed()) continue;
    const on = S.pauseScope === 'monitor' ? hit(w._r) : any;
    if (on !== !!w._full) { w._full = on; changed = true; }
  }
  if (changed) sendPause();
}

function showPanel() {
  if (panel) return panel.show();
  panel = new BrowserWindow({ width: 980, height: 680, minWidth: 760, minHeight: 520, backgroundColor: MICA ? '#00000000' : (nativeTheme.shouldUseDarkColors ? '#0d0f17' : '#f3f4fa'),
    ...(MICA ? { backgroundMaterial: 'mica' } : {}), titleBarStyle: 'hidden', titleBarOverlay: overlay(),
    title: 'Wallpaper Vivo', icon, autoHideMenuBar: true, webPreferences: { preload } });
  panel.loadFile(path.join(__dirname, 'panel.html'), { query: MICA ? { mica: 1 } : {} });
  panel.on('close', e => { if (!app.isQuitting) { e.preventDefault(); panel.hide(); } });
}
function buildTray() {
  if (!tray) {
    tray = new Tray(icon.resize({ width: 16, height: 16 }));
    tray.on('double-click', showPanel);
  }
  tray.setToolTip('Wallpaper Vivo');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Abrir painel', click: showPanel },
    { label: manual ? 'Continuar' : 'Pausar', click: () => { manual = !manual; sendPause(); } },
    { label: 'Próximo wallpaper', click: nextWallpaper },
    { label: 'Parar wallpaper', click: () => { S.current = null; save(); stopWalls(); } },
    { type: 'separator' },
    { label: 'Sair', click: () => { app.isQuitting = true; stopWalls(); app.quit(); } }
  ]));
}

ipcMain.handle('state', () => S);
ipcMain.handle('apply', (_, item) => { S.current = item; save(); switchWalls(); return S; });
ipcMain.handle('stop', () => { S.current = null; save(); stopWalls(); return S; });
ipcMain.handle('plist', (_, item) => {
  const k = S.playlist.findIndex(i => i.src === item.src);
  if (k >= 0) S.playlist.splice(k, 1); else S.playlist.push(item);
  save(); schedulePlaylist(); return S;
});
// ---------- Loja ----------
const dlDir = () => { const d = path.join(app.getPath('userData'), 'wallpapers'); fs.mkdirSync(d, { recursive: true }); return d; };
async function fetchToLibrary(e, it) {
  const base = (it.source || 'wp') + '-' + crypto.createHash('sha1').update(it.key).digest('hex').slice(0, 12);
  const file = await store.download(it.url, dlDir(), base, p => e.sender.send('dl', { key: it.key, p }));
  const item = { type: store.typeOf(file), src: pathToFileURL(file).href, name: it.title + (it.author ? ' · ' + it.author : ''), author: it.author || '',
    source: it.source || '', page: it.page || '', origin: it.key, local: file };
  const k = S.library.findIndex(i => i.origin === it.key); if (k >= 0) S.library[k] = item; else S.library.push(item);
  save(); return item;
}
ipcMain.handle('store-search', async (_, o) => {
  try {
    const k = S.keys || {}, src = String((o || {}).source || '');
    if (src.startsWith('wallhaven')) return await store.wallhaven({ ...o, cats: src === 'wallhaven-anime' ? '010' : src === 'wallhaven-geral' ? '100' : '110' });
    if (src === 'nekos') return await store.nekos(o);
    if (src === 'pexels') return await store.pexels(o, k.pexels);
    if (src === 'pixabay') return await store.pixabay(o, k.pixabay);
    if (src === 'pixabay-anim') return await store.pixabay({ ...o, type: 'animation' }, k.pixabay);
    if (src.startsWith('cat:')) return await store.catalog(src.slice(4), o.q);
    throw new Error('Fonte desconhecida.');
  } catch (e) { return { error: e.message }; }
});
ipcMain.handle('store-download', async (e, it) => {
  try { if (!it || !/^https?:\/\//i.test(it.url || '') || !it.key) throw new Error('Item inválido.'); await fetchToLibrary(e, it); return { S }; }
  catch (err) { return { error: err.message }; }
});
ipcMain.handle('store-url', async (e, url) => {
  try {
    if (!/^https?:\/\//i.test(url || '')) throw new Error('Cole um link http(s) direto para um vídeo ou imagem.');
    const name = decodeURIComponent(path.basename(new URL(url).pathname)).replace(/\.[a-z0-9]+$/i, '') || 'Link direto';
    await fetchToLibrary(e, { url, key: 'url:' + url, title: name, source: 'Link' }); return { S };
  } catch (err) { return { error: err.message }; }
});
ipcMain.handle('catalog-add', async (_, url) => {
  try {
    if (!/^https?:\/\//i.test(url || '')) throw new Error('Use um link http(s).');
    const j = await store.json(url);
    if (!Array.isArray(j.items)) throw new Error('JSON inválido: falta a lista "items".');
    S.catalogs = S.catalogs.filter(c => c.url !== url).concat({ name: String(j.name || new URL(url).hostname), url }); save(); return { S };
  } catch (err) { return { error: err.message }; }
});
ipcMain.handle('open-url', (_, u) => { if (/^https:\/\//i.test(u || '')) shell.openExternal(u); });
// ---------- Pasta observada e arrastar-e-soltar ----------
const MEDIA = ['.mp4', '.webm', '.jpg', '.jpeg', '.png', '.webp', '.gif'];
const notify = () => { if (panel && !panel.isDestroyed()) panel.webContents.send('state', S); };
function addLocalFile(p, extra = {}) {
  if (!MEDIA.includes(path.extname(p).toLowerCase())) return null;
  const src = pathToFileURL(p).href; if (S.library.some(i => i.src === src)) return null;
  const item = { type: store.typeOf(p), src, name: path.basename(p), ...extra }; S.library.push(item); return item;
}
let watcher = null, watchTimer = null, scanning = false;
function stopWatch() { try { watcher && watcher.close(); } catch {} watcher = null; clearTimeout(watchTimer); }
const scheduleScan = (ms = 1500) => { clearTimeout(watchTimer); watchTimer = setTimeout(scanWatch, ms); };
function startWatch() {
  stopWatch(); if (!S.watchOn) return;
  if (!S.watchDir) { S.watchDir = path.join(app.getPath('pictures'), 'Wallpaper Vivo'); save(); }
  try { fs.mkdirSync(S.watchDir, { recursive: true }); watcher = fs.watch(S.watchDir, () => scheduleScan()); watcher.on('error', () => {}); } catch (e) { console.error(e); }
  scheduleScan(300);
}
async function scanWatch() {
  if (scanning) return scheduleScan(1500);
  scanning = true; let changed = false, added = 0;
  try {
    const gone = i => i.watched && !fs.existsSync(i.watched), n0 = S.library.length + S.playlist.length;
    S.library = S.library.filter(i => !gone(i)); S.playlist = S.playlist.filter(i => !gone(i));
    if (S.library.length + S.playlist.length !== n0) changed = true;
    for (const f of fs.readdirSync(S.watchDir)) {
      const p = path.join(S.watchDir, f);
      if (!MEDIA.includes(path.extname(f).toLowerCase()) || (S.watchIgnore || []).includes(p) || S.library.some(i => i.src === pathToFileURL(p).href)) continue;
      let a; try { a = fs.statSync(p); } catch { continue; } if (!a.isFile() || !a.size) continue;
      await new Promise(r => setTimeout(r, 800));                    // espera o download terminar de gravar
      let b; try { b = fs.statSync(p); } catch { continue; }
      if (b.size !== a.size) { scheduleScan(2000); continue; }
      if (addLocalFile(p, { watched: p, source: 'Pasta' })) { changed = true; if (++added >= 200) break; }
    }
    if (changed) { save(); notify(); }
    if (added) panel && !panel.isDestroyed() && panel.webContents.send('toast', added + ' arquivo(s) novo(s) da pasta adicionado(s) à Biblioteca.');
  } catch (e) { console.error(e); } finally { scanning = false; }
}
ipcMain.handle('watch-pick', async () => {
  const r = await dialog.showOpenDialog(panel, { properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled) return S;
  S.watchDir = r.filePaths[0]; S.watchIgnore = []; S.watchOn = true; save(); startWatch(); return S;
});
ipcMain.handle('watch-open', () => { if (S.watchDir) { fs.mkdirSync(S.watchDir, { recursive: true }); shell.openPath(S.watchDir); } });
ipcMain.handle('add-files', (_, paths) => {
  let n = 0; for (const p of (paths || [])) if (typeof p === 'string' && p && fs.existsSync(p) && addLocalFile(p)) n++;
  if (n) save(); return { S, n };
});
ipcMain.handle('drop-blob', (_, { name, data }) => {
  try {
    const ext = path.extname(String(name || '')).toLowerCase(); if (!MEDIA.includes(ext)) throw new Error('Tipo de arquivo não suportado.');
    const buf = Buffer.from(data); if (!buf.length || buf.length > 150 * 1024 * 1024) throw new Error('Arquivo vazio ou grande demais (máximo 150 MB).');
    const base = 'drop-' + crypto.createHash('sha1').update(buf).digest('hex').slice(0, 12), file = path.join(dlDir(), base + ext);
    fs.writeFileSync(file, buf);
    const item = { type: store.typeOf(file), src: pathToFileURL(file).href, name: String(name).replace(/\.[a-z0-9]+$/i, ''), source: 'Arrastado', origin: 'drop:' + base, local: file };
    if (!S.library.some(i => i.src === item.src)) S.library.push(item); save(); return { S };
  } catch (e) { return { error: e.message }; }
});
const sendUpd = s => { if (panel && !panel.isDestroyed()) panel.webContents.send('update', s); };
ipcMain.handle('version', () => app.getVersion() + (app.isPackaged ? '' : ' (modo de teste)'));
ipcMain.handle('displays', () => {
  const on = targetDisplays().map(d => d.id), pid = screen.getPrimaryDisplay().id;
  return sortedDisplays().map((d, i) => ({ id: d.id, n: i + 1, w: Math.round(d.size.width * d.scaleFactor), h: Math.round(d.size.height * d.scaleFactor), primary: d.id === pid, on: on.includes(d.id) }));
});
ipcMain.handle('identify-displays', () => {            // mostra o número de cada monitor por 2 segundos
  sortedDisplays().forEach((d, i) => {
    const b = d.bounds, w = new BrowserWindow({ x: b.x + 40, y: b.y + 40, width: 220, height: 220, frame: false, transparent: true, alwaysOnTop: true, focusable: false, skipTaskbar: true, resizable: false, show: false });
    w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent('<body style="margin:0;height:100vh;display:grid;place-items:center;font:700 130px Segoe UI,sans-serif;color:#fff;background:rgba(20,22,40,.88);border:5px solid #8b9cff;box-sizing:border-box;border-radius:30px">' + (i + 1) + '</body>'));
    w.once('ready-to-show', () => w.showInactive()); setTimeout(() => { if (!w.isDestroyed()) w.destroy(); }, 2200);
  });
});
ipcMain.handle('update-check', () => updater.check(sendUpd));
ipcMain.handle('update-install', () => updater.install());
ipcMain.handle('pick-media', async () => {
  const r = await dialog.showOpenDialog(panel, { properties: ['openFile'], filters: [{ name: 'Imagem, GIF ou vídeo', extensions: ['png', 'jpg', 'jpeg', 'webp', 'gif', 'mp4', 'webm'] }] });
  if (r.canceled) return null; const p = r.filePaths[0]; return { src: pathToFileURL(p).href, name: path.basename(p) };
});
ipcMain.handle('scene-init', () => S.current ? sceneArgs() : null);
ipcMain.handle('saveCustom', (_, item) => {
  const k = S.library.findIndex(i => i.src === item.src);
  if (k >= 0) S.library[k] = item; else S.library.push(item);
  const p = S.playlist.findIndex(i => i.src === item.src); if (p >= 0) S.playlist[p] = item;
  if (S.current && S.current.src === item.src) { S.current = item; switchWalls(); }
  save(); return S;
});
ipcMain.handle('next', () => { nextWallpaper(); return S; });
ipcMain.handle('remove', (_, src) => {
  const rm = S.library.find(i => i.src === src); if (rm && rm.watched) S.watchIgnore = (S.watchIgnore || []).concat(rm.watched); if (rm && rm.local) setTimeout(() => fs.unlink(rm.local, () => {}), 1500);
  S.library = S.library.filter(i => i.src !== src); S.playlist = S.playlist.filter(i => i.src !== src); schedulePlaylist();
  if (S.current && S.current.src === src) { S.current = null; stopWalls(); }
  save(); return S;
});
ipcMain.handle('pick', async () => {
  const r = await dialog.showOpenDialog(panel, { properties: ['openFile'], filters: [
    { name: 'Vídeo, imagem ou página HTML', extensions: ['mp4', 'webm', 'gif', 'png', 'jpg', 'jpeg', 'webp', 'html'] }] });
  if (r.canceled) return S;
  const p = r.filePaths[0], ext = path.extname(p).slice(1).toLowerCase();
  const type = ['mp4', 'webm'].includes(ext) ? 'video' : ext === 'html' ? 'html' : 'image';
  const item = { type, src: pathToFileURL(p).href, name: path.basename(p) };
  if (!S.library.some(i => i.src === item.src)) S.library.push(item);
  save(); return S;
});
ipcMain.handle('opt', (_, k, v) => {
  S[k] = v; save();
  if (k === 'autostart') applyAutostart(!!v);
  if (k === 'theme') nativeTheme.themeSource = v === 'auto' ? 'system' : v;
  if (k === 'watchOn') startWatch();
  if (k === 'monitors' || k === 'monitorIds') startWalls();
  if (['fps', 'muted', 'fade'].includes(k)) switchWalls();
  if (k === 'pauseOnBattery') { battery = !!v && powerMonitor.isOnBatteryPower(); sendPause(); }
  if (k === 'pauseOnFullscreen' || k === 'pauseScope') pollFull();
  if (['playEnabled', 'playMinutes', 'playRandom'].includes(k)) schedulePlaylist();
  return S;
});

app.whenReady().then(async () => {
  await loadWallpaperLib();
  nativeTheme.themeSource = S.theme === 'auto' ? 'system' : S.theme;
  nativeTheme.on('updated', () => { if (panel && !panel.isDestroyed()) panel.setTitleBarOverlay(overlay()); });
  session.defaultSession.setDisplayMediaRequestHandler(async (req, cb) => {
    try { const s = await desktopCapturer.getSources({ types: ['screen'] }); cb({ video: s[0], audio: 'loopback' }); } catch { cb({}); }
  });
  schedulePlaylist(); startWatch();
  if (S.autoUpdate !== false && app.isPackaged) setTimeout(() => updater.check(sendUpd), 8000);
  battery = S.pauseOnBattery && powerMonitor.isOnBatteryPower();
  buildTray(); if (!process.argv.includes('--hidden')) showPanel(); startWalls();          // iniciado com o Windows: fica só na bandeja
  if (app.isPackaged && S.autostart) applyAutostart(true);                                  // mantém a entrada de inicialização atualizada
  powerMonitor.on('on-battery', () => { if (S.pauseOnBattery) { battery = true; sendPause(); } });
  powerMonitor.on('on-ac', () => { battery = false; sendPause(); });
  setInterval(pollFull, 500);
  setInterval(pollCursor, 33);
  let t; const redo = () => { clearTimeout(t); t = setTimeout(() => { startWalls(); if (panel && !panel.isDestroyed()) panel.webContents.send('displays'); }, 800); };
  ['display-added', 'display-removed', 'display-metrics-changed'].forEach(e => screen.on(e, redo));
});
app.on('second-instance', showPanel);
app.on('window-all-closed', () => {});
